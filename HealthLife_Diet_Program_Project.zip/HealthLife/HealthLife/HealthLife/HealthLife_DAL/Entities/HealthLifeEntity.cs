﻿using HealthLife_Model.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthLife_DAL.Entities
{
    public class HealthLifeEntity:DbContext
    {
        public HealthLifeEntity()
        {

        }

        public HealthLifeEntity(DbContextOptions<HealthLifeEntity> options): base(options)
        {

        }

        public virtual DbSet<Product> Products { get; set; }
        public virtual DbSet<Category> Categories { get; set; }
        public virtual DbSet<Meal> Meals { get; set; }
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<MealProduct> MealProducts { get; set; }
        

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=DESKTOP-O07KLML\SQLEXPRESS;Database=HealthLifeDB;Trusted_Connection=True;Trust Server Certificate=true");
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            AddSeedData(modelBuilder);
        }
        //Photo = File.ReadAllBytes("resmin bulunduğu yol") bunu productlara ekleyeceğiz
        public void AddSeedData(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>().HasData(
                new Category { Id = 1, Name= "Vegetables"},
                new Category { Id = 2, Name = "Meats"},
                new Category { Id = 3, Name = "Sea Foods"},
                new Category { Id = 4, Name = "Snacks" },
                new Category { Id = 5, Name = "Fruits" },
                new Category { Id = 6, Name = "Alcohols" },
                new Category { Id = 7, Name = "Soft Drinks" },
                new Category { Id = 8, Name = "Dairy Products" },
                new Category { Id = 9, Name = "Desserts" },
                new Category { Id = 10, Name = "Legumes" }
                );
            modelBuilder.Entity<Product>().HasData(
                new Product { Id = 1, Name = "Apple", CategoryId = 5, UnitCalorie = 52 },
                new Product { Id = 2, Name = "Watermelon", CategoryId = 5, UnitCalorie = 30.4 },
                new Product { Id = 3, Name = "Banana", CategoryId = 5, UnitCalorie = 88.7 },
                new Product { Id = 4, Name = "Strawberry", CategoryId = 5, UnitCalorie = 32 },
                new Product { Id = 5, Name = "Plum", CategoryId = 5, UnitCalorie = 45.9 },
                new Product { Id = 6, Name = "Veal", CategoryId = 2, UnitCalorie = 172  },
                new Product { Id = 7, Name = "Chicken", CategoryId = 2, UnitCalorie = 239 },
                new Product { Id = 8, Name = "Pork", CategoryId = 2, UnitCalorie = 242 },
                new Product { Id = 9, Name = "Sausage", CategoryId = 2, UnitCalorie = 300 },
                new Product { Id = 10, Name = "Bacon", CategoryId = 2, UnitCalorie = 540 },
                new Product { Id = 11, Name = "Leek", CategoryId = 1, UnitCalorie = 60.9 },
                new Product { Id = 12, Name = "Spinach", CategoryId = 1, UnitCalorie = 23.2 },
                new Product { Id = 13, Name = "Lettuce", CategoryId = 1, UnitCalorie = 14.8 },
                new Product { Id = 14, Name = "Cauliflower", CategoryId = 1, UnitCalorie = 24.9 },
                new Product { Id = 15, Name = "Potato", CategoryId = 1, UnitCalorie = 87 },
                new Product { Id = 16, Name = "Shrimp", CategoryId = 3, UnitCalorie = 99 },
                new Product { Id = 17, Name = "Squid", CategoryId = 3, UnitCalorie = 174.9 },
                new Product { Id = 18, Name = "Octopus", CategoryId = 3, UnitCalorie = 163 },
                new Product { Id = 19, Name = "Chocolate", CategoryId = 4, UnitCalorie = 545 },
                new Product { Id = 20, Name = "Chips", CategoryId = 4, UnitCalorie = 536 },
                new Product { Id = 21, Name = "Nuts", CategoryId = 4, UnitCalorie = 606.8 },
                new Product { Id = 22, Name = "Biscuit", CategoryId = 4, UnitCalorie = 353 },
                new Product { Id = 23, Name = "Jelly Bean", CategoryId = 4, UnitCalorie = 374 },
                new Product { Id = 24, Name = "Beer", CategoryId = 6, UnitCalorie = 43 },
                new Product { Id = 25, Name = "Vodka", CategoryId = 6, UnitCalorie = 231 },
                new Product { Id = 26, Name = "Wine", CategoryId = 6, UnitCalorie = 82.9 },
                new Product { Id = 27, Name = "Whiskey", CategoryId = 6, UnitCalorie = 250 },
                new Product { Id = 28, Name = "Tequila", CategoryId = 6, UnitCalorie = 231 },
                new Product { Id = 29, Name = "Cola", CategoryId = 7, UnitCalorie = 37 },
                new Product { Id = 30, Name = "Ayran", CategoryId = 7, UnitCalorie = 25 },
                new Product { Id = 31, Name = "Soda", CategoryId = 7, UnitCalorie = 95 },
                new Product { Id = 32, Name = "Lemonade", CategoryId = 7, UnitCalorie = 40  },
                new Product { Id = 33, Name = "Sparkling Water", CategoryId = 7, UnitCalorie = 0},
                new Product { Id = 34, Name = "Milk", CategoryId = 8, UnitCalorie = 42.3 },
                new Product { Id = 35, Name = "Yogurt", CategoryId = 8, UnitCalorie = 58.8 },
                new Product { Id = 36, Name = "Cheese", CategoryId = 8, UnitCalorie = 402 },
                new Product { Id = 37, Name = "Cream Cheese", CategoryId = 8, UnitCalorie = 442 },
                new Product { Id = 38, Name = "Cheddar", CategoryId = 8, UnitCalorie = 402.5 },
                new Product { Id = 39, Name = "Chocolate Cake", CategoryId = 9, UnitCalorie = 370.7 },
                new Product { Id = 40, Name = "Cheese Cake", CategoryId = 9, UnitCalorie = 321 },
                new Product { Id = 41, Name = "Pudding", CategoryId = 9, UnitCalorie = 119.5 },
                new Product { Id = 42, Name = "Baklava", CategoryId = 9, UnitCalorie = 451 },
                new Product { Id = 43, Name = "Künefe", CategoryId = 9, UnitCalorie = 315 },
                new Product { Id = 44, Name = "Magnolia", CategoryId = 9, UnitCalorie = 42 },
                new Product { Id = 45, Name = "Rice", CategoryId = 10, UnitCalorie = 130 },
                new Product { Id = 46, Name = "Beans", CategoryId = 10, UnitCalorie = 347 },
                new Product { Id = 47, Name = "Chickpeas", CategoryId = 10, UnitCalorie = 364 },
                new Product { Id = 48, Name = "Lentils", CategoryId = 10, UnitCalorie = 116 },
                new Product { Id = 49, Name = "Peas", CategoryId = 10, UnitCalorie = 81 },
                new Product { Id = 50, Name = "Black beans", CategoryId = 10, UnitCalorie = 91 }
                );
        }
    }
}
