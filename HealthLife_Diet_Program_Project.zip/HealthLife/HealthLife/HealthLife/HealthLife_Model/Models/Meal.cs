﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthLife_Model.Models
{
    public class Meal
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime Date { get; set; }
        public int UserId { get; set; }
        [Browsable(false)]
        public virtual User User { get; set; }
        [Browsable(false)]
        public virtual ICollection<MealProduct> MealProducts { get; set; } = new List<MealProduct>();
    }
}
