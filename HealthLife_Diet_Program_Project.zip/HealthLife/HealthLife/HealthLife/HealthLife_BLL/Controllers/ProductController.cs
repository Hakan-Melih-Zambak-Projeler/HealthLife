﻿using HealthLife_DAL.Entities;
using HealthLife_Model.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthLife_BLL.Controllers
{
    public static class ProductController
    {
        private static HealthLifeEntity _context = new HealthLifeEntity();

        public static void AddProduct(Product product)
        {
            _context.Products.Add(product);
            _context.SaveChanges();
        }

        public static void RemoveProduct(Product product)
        {
            _context.Products.Remove(product);
            _context.SaveChanges();
        }
        public static void UpdateProduct(Product product)
        {
            _context.Products.Attach(product);
            _context.Entry(product).State = EntityState.Modified;
            _context.SaveChanges();
        }
        public static List<string> GetProductName()
        {
            return _context.Products.Select(c => c.Name).ToList();
        }
        public static void AddPhoto()
        {

        }
        public static int GetProductIDByName(string productName)
        {
            return _context.Products.FirstOrDefault(x => x.Name == productName).Id;
        }
        public static List<Product> GetProductsByCategory(int categoryID) 
        { 
            return _context.Products.Where(x=>x.CategoryId == categoryID).ToList();
        
        }
        
        public static List<Product> GetProducts() 
        { 
            return _context.Products.ToList();
        }
        
    }
}
