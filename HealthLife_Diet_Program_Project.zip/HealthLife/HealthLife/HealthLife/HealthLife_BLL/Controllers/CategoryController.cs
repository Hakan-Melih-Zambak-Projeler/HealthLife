﻿using HealthLife_DAL.Entities;
using HealthLife_Model.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthLife_BLL.Controllers
{
    public static class  CategoryController
    {
        private static HealthLifeEntity _context = new HealthLifeEntity();

        public static void AddCategory(Category category)
        {
            _context.Categories.Add(category);
            _context.SaveChanges();
        }

        public static void RemoveCategory(Category category)
        {
            _context.Categories.Remove(category);
            _context.SaveChanges();
        }
        public static void UpdateCategory(Category category)
        {
            _context.Categories.Attach(category);
            _context.Entry(category).State = EntityState.Modified;
            _context.SaveChanges();
        }
        public static List<string> GetCategoryName()
        {
            return _context.Categories.Select(c => c.Name).ToList();     
        }
        public static List<Category> GetCategories() 
        { 
            return _context.Categories.ToList();
        }
    }
}
