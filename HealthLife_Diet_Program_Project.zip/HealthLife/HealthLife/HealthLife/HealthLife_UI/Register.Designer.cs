﻿namespace HealthLife_UI
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Register));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuGradientPanel1 = new Bunifu.UI.WinForms.BunifuGradientPanel();
            this.bunifuPictureBox1 = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.btnBackRegister = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuLabel3 = new Bunifu.UI.WinForms.BunifuLabel();
            this.btnRegisterRegister = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuLabel4 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel2 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.txtRePasswordRegister = new Bunifu.UI.WinForms.BunifuTextBox();
            this.txtPasswordRegister = new Bunifu.UI.WinForms.BunifuTextBox();
            this.txtEMailRegister = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.BorderRadius = 1;
            this.bunifuGradientPanel1.Controls.Add(this.bunifuPictureBox1);
            this.bunifuGradientPanel1.Controls.Add(this.btnBackRegister);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel3);
            this.bunifuGradientPanel1.Controls.Add(this.btnRegisterRegister);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel4);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel2);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel1);
            this.bunifuGradientPanel1.Controls.Add(this.txtRePasswordRegister);
            this.bunifuGradientPanel1.Controls.Add(this.txtPasswordRegister);
            this.bunifuGradientPanel1.Controls.Add(this.txtEMailRegister);
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(92)))), ((int)(((byte)(188)))));
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.DeepPink;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.DodgerBlue;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(-9, -9);
            this.bunifuGradientPanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1384, 1080);
            this.bunifuGradientPanel1.TabIndex = 1;
            // 
            // bunifuPictureBox1
            // 
            this.bunifuPictureBox1.AllowFocused = false;
            this.bunifuPictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuPictureBox1.AutoSizeHeight = true;
            this.bunifuPictureBox1.BorderRadius = 0;
            this.bunifuPictureBox1.Image = global::HealthLife_UI.Properties.Resources.Company_logo_21;
            this.bunifuPictureBox1.IsCircle = false;
            this.bunifuPictureBox1.Location = new System.Drawing.Point(478, 25);
            this.bunifuPictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuPictureBox1.Name = "bunifuPictureBox1";
            this.bunifuPictureBox1.Size = new System.Drawing.Size(417, 417);
            this.bunifuPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuPictureBox1.TabIndex = 5;
            this.bunifuPictureBox1.TabStop = false;
            this.bunifuPictureBox1.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Square;
            // 
            // btnBackRegister
            // 
            this.btnBackRegister.ActiveBorderThickness = 1;
            this.btnBackRegister.ActiveCornerRadius = 20;
            this.btnBackRegister.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnBackRegister.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnBackRegister.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnBackRegister.BackColor = System.Drawing.Color.Transparent;
            this.btnBackRegister.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBackRegister.BackgroundImage")));
            this.btnBackRegister.ButtonText = "Back";
            this.btnBackRegister.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnBackRegister.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnBackRegister.IdleBorderThickness = 2;
            this.btnBackRegister.IdleCornerRadius = 20;
            this.btnBackRegister.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnBackRegister.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnBackRegister.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnBackRegister.Location = new System.Drawing.Point(1176, 981);
            this.btnBackRegister.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.btnBackRegister.Name = "btnBackRegister";
            this.btnBackRegister.Size = new System.Drawing.Size(189, 76);
            this.btnBackRegister.TabIndex = 3;
            this.btnBackRegister.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnBackRegister.Click += new System.EventHandler(this.btnBackRegister_Click);
            // 
            // bunifuLabel3
            // 
            this.bunifuLabel3.AllowParentOverrides = false;
            this.bunifuLabel3.AutoEllipsis = false;
            this.bunifuLabel3.AutoSize = false;
            this.bunifuLabel3.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel3.Font = new System.Drawing.Font("Monotype Corsiva", 35F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel3.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel3.Location = new System.Drawing.Point(429, 500);
            this.bunifuLabel3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuLabel3.Name = "bunifuLabel3";
            this.bunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel3.Size = new System.Drawing.Size(192, 75);
            this.bunifuLabel3.TabIndex = 3;
            this.bunifuLabel3.Text = "Register";
            this.bunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // btnRegisterRegister
            // 
            this.btnRegisterRegister.ActiveBorderThickness = 1;
            this.btnRegisterRegister.ActiveCornerRadius = 20;
            this.btnRegisterRegister.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnRegisterRegister.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnRegisterRegister.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnRegisterRegister.BackColor = System.Drawing.Color.Transparent;
            this.btnRegisterRegister.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnRegisterRegister.BackgroundImage")));
            this.btnRegisterRegister.ButtonText = "Register";
            this.btnRegisterRegister.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnRegisterRegister.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnRegisterRegister.IdleBorderThickness = 2;
            this.btnRegisterRegister.IdleCornerRadius = 20;
            this.btnRegisterRegister.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnRegisterRegister.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnRegisterRegister.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnRegisterRegister.Location = new System.Drawing.Point(574, 825);
            this.btnRegisterRegister.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.btnRegisterRegister.Name = "btnRegisterRegister";
            this.btnRegisterRegister.Size = new System.Drawing.Size(189, 76);
            this.btnRegisterRegister.TabIndex = 2;
            this.btnRegisterRegister.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnRegisterRegister.Click += new System.EventHandler(this.btnRegisterRegister_Click);
            // 
            // bunifuLabel4
            // 
            this.bunifuLabel4.AllowParentOverrides = false;
            this.bunifuLabel4.AutoEllipsis = false;
            this.bunifuLabel4.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel4.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel4.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel4.Location = new System.Drawing.Point(394, 764);
            this.bunifuLabel4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuLabel4.Name = "bunifuLabel4";
            this.bunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel4.Size = new System.Drawing.Size(137, 31);
            this.bunifuLabel4.TabIndex = 1;
            this.bunifuLabel4.Text = "Re-Password";
            this.bunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel4.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel2
            // 
            this.bunifuLabel2.AllowParentOverrides = false;
            this.bunifuLabel2.AutoEllipsis = false;
            this.bunifuLabel2.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel2.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel2.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel2.Location = new System.Drawing.Point(394, 689);
            this.bunifuLabel2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuLabel2.Name = "bunifuLabel2";
            this.bunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel2.Size = new System.Drawing.Size(101, 31);
            this.bunifuLabel2.TabIndex = 1;
            this.bunifuLabel2.Text = "Password";
            this.bunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel2.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AllowParentOverrides = false;
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel1.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel1.Location = new System.Drawing.Point(394, 613);
            this.bunifuLabel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(69, 31);
            this.bunifuLabel1.TabIndex = 1;
            this.bunifuLabel1.Text = "E-Mail";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // txtRePasswordRegister
            // 
            this.txtRePasswordRegister.AcceptsReturn = false;
            this.txtRePasswordRegister.AcceptsTab = false;
            this.txtRePasswordRegister.AnimationSpeed = 200;
            this.txtRePasswordRegister.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtRePasswordRegister.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtRePasswordRegister.AutoSizeHeight = true;
            this.txtRePasswordRegister.BackColor = System.Drawing.Color.Transparent;
            this.txtRePasswordRegister.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtRePasswordRegister.BackgroundImage")));
            this.txtRePasswordRegister.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtRePasswordRegister.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtRePasswordRegister.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtRePasswordRegister.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtRePasswordRegister.BorderRadius = 1;
            this.txtRePasswordRegister.BorderThickness = 2;
            this.txtRePasswordRegister.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.txtRePasswordRegister.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtRePasswordRegister.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtRePasswordRegister.DefaultText = "";
            this.txtRePasswordRegister.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.txtRePasswordRegister.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.txtRePasswordRegister.HideSelection = true;
            this.txtRePasswordRegister.IconLeft = null;
            this.txtRePasswordRegister.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtRePasswordRegister.IconPadding = 10;
            this.txtRePasswordRegister.IconRight = null;
            this.txtRePasswordRegister.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtRePasswordRegister.Lines = new string[0];
            this.txtRePasswordRegister.Location = new System.Drawing.Point(539, 748);
            this.txtRePasswordRegister.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtRePasswordRegister.MaxLength = 32767;
            this.txtRePasswordRegister.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtRePasswordRegister.Modified = false;
            this.txtRePasswordRegister.Multiline = false;
            this.txtRePasswordRegister.Name = "txtRePasswordRegister";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtRePasswordRegister.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtRePasswordRegister.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtRePasswordRegister.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            stateProperties4.ForeColor = System.Drawing.Color.DarkTurquoise;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtRePasswordRegister.OnIdleState = stateProperties4;
            this.txtRePasswordRegister.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtRePasswordRegister.PasswordChar = '*';
            this.txtRePasswordRegister.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtRePasswordRegister.PlaceholderText = "Enter text";
            this.txtRePasswordRegister.ReadOnly = false;
            this.txtRePasswordRegister.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtRePasswordRegister.SelectedText = "";
            this.txtRePasswordRegister.SelectionLength = 0;
            this.txtRePasswordRegister.SelectionStart = 0;
            this.txtRePasswordRegister.ShortcutsEnabled = true;
            this.txtRePasswordRegister.Size = new System.Drawing.Size(317, 67);
            this.txtRePasswordRegister.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtRePasswordRegister.TabIndex = 3;
            this.txtRePasswordRegister.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtRePasswordRegister.TextMarginBottom = 0;
            this.txtRePasswordRegister.TextMarginLeft = 3;
            this.txtRePasswordRegister.TextMarginTop = 1;
            this.txtRePasswordRegister.TextPlaceholder = "Enter text";
            this.txtRePasswordRegister.UseSystemPasswordChar = false;
            this.txtRePasswordRegister.WordWrap = true;
            // 
            // txtPasswordRegister
            // 
            this.txtPasswordRegister.AcceptsReturn = false;
            this.txtPasswordRegister.AcceptsTab = false;
            this.txtPasswordRegister.AnimationSpeed = 200;
            this.txtPasswordRegister.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtPasswordRegister.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtPasswordRegister.AutoSizeHeight = true;
            this.txtPasswordRegister.BackColor = System.Drawing.Color.Transparent;
            this.txtPasswordRegister.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtPasswordRegister.BackgroundImage")));
            this.txtPasswordRegister.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtPasswordRegister.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtPasswordRegister.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtPasswordRegister.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtPasswordRegister.BorderRadius = 1;
            this.txtPasswordRegister.BorderThickness = 2;
            this.txtPasswordRegister.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.txtPasswordRegister.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtPasswordRegister.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtPasswordRegister.DefaultText = "";
            this.txtPasswordRegister.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.txtPasswordRegister.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.txtPasswordRegister.HideSelection = true;
            this.txtPasswordRegister.IconLeft = null;
            this.txtPasswordRegister.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPasswordRegister.IconPadding = 10;
            this.txtPasswordRegister.IconRight = null;
            this.txtPasswordRegister.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPasswordRegister.Lines = new string[0];
            this.txtPasswordRegister.Location = new System.Drawing.Point(539, 673);
            this.txtPasswordRegister.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPasswordRegister.MaxLength = 32767;
            this.txtPasswordRegister.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtPasswordRegister.Modified = false;
            this.txtPasswordRegister.Multiline = false;
            this.txtPasswordRegister.Name = "txtPasswordRegister";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtPasswordRegister.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtPasswordRegister.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtPasswordRegister.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            stateProperties8.ForeColor = System.Drawing.Color.DarkTurquoise;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtPasswordRegister.OnIdleState = stateProperties8;
            this.txtPasswordRegister.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPasswordRegister.PasswordChar = '*';
            this.txtPasswordRegister.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtPasswordRegister.PlaceholderText = "Enter text";
            this.txtPasswordRegister.ReadOnly = false;
            this.txtPasswordRegister.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPasswordRegister.SelectedText = "";
            this.txtPasswordRegister.SelectionLength = 0;
            this.txtPasswordRegister.SelectionStart = 0;
            this.txtPasswordRegister.ShortcutsEnabled = true;
            this.txtPasswordRegister.Size = new System.Drawing.Size(317, 67);
            this.txtPasswordRegister.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtPasswordRegister.TabIndex = 2;
            this.txtPasswordRegister.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtPasswordRegister.TextMarginBottom = 0;
            this.txtPasswordRegister.TextMarginLeft = 3;
            this.txtPasswordRegister.TextMarginTop = 1;
            this.txtPasswordRegister.TextPlaceholder = "Enter text";
            this.txtPasswordRegister.UseSystemPasswordChar = false;
            this.txtPasswordRegister.WordWrap = true;
            // 
            // txtEMailRegister
            // 
            this.txtEMailRegister.AcceptsReturn = false;
            this.txtEMailRegister.AcceptsTab = false;
            this.txtEMailRegister.AnimationSpeed = 200;
            this.txtEMailRegister.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtEMailRegister.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtEMailRegister.AutoSizeHeight = true;
            this.txtEMailRegister.BackColor = System.Drawing.Color.Transparent;
            this.txtEMailRegister.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtEMailRegister.BackgroundImage")));
            this.txtEMailRegister.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtEMailRegister.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtEMailRegister.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtEMailRegister.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtEMailRegister.BorderRadius = 1;
            this.txtEMailRegister.BorderThickness = 2;
            this.txtEMailRegister.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.txtEMailRegister.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtEMailRegister.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtEMailRegister.DefaultText = "";
            this.txtEMailRegister.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.txtEMailRegister.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.txtEMailRegister.HideSelection = true;
            this.txtEMailRegister.IconLeft = null;
            this.txtEMailRegister.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEMailRegister.IconPadding = 10;
            this.txtEMailRegister.IconRight = null;
            this.txtEMailRegister.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEMailRegister.Lines = new string[0];
            this.txtEMailRegister.Location = new System.Drawing.Point(539, 599);
            this.txtEMailRegister.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtEMailRegister.MaxLength = 32767;
            this.txtEMailRegister.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtEMailRegister.Modified = false;
            this.txtEMailRegister.Multiline = false;
            this.txtEMailRegister.Name = "txtEMailRegister";
            stateProperties9.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtEMailRegister.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtEMailRegister.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtEMailRegister.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            stateProperties12.ForeColor = System.Drawing.Color.DarkTurquoise;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtEMailRegister.OnIdleState = stateProperties12;
            this.txtEMailRegister.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtEMailRegister.PasswordChar = '\0';
            this.txtEMailRegister.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtEMailRegister.PlaceholderText = "Enter text";
            this.txtEMailRegister.ReadOnly = false;
            this.txtEMailRegister.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtEMailRegister.SelectedText = "";
            this.txtEMailRegister.SelectionLength = 0;
            this.txtEMailRegister.SelectionStart = 0;
            this.txtEMailRegister.ShortcutsEnabled = true;
            this.txtEMailRegister.Size = new System.Drawing.Size(317, 67);
            this.txtEMailRegister.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtEMailRegister.TabIndex = 1;
            this.txtEMailRegister.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtEMailRegister.TextMarginBottom = 0;
            this.txtEMailRegister.TextMarginLeft = 3;
            this.txtEMailRegister.TextMarginTop = 1;
            this.txtEMailRegister.TextPlaceholder = "Enter text";
            this.txtEMailRegister.UseSystemPasswordChar = false;
            this.txtEMailRegister.WordWrap = true;
            // 
            // Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1371, 1067);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Register";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Register";
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuPictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel3;
        private Bunifu.Framework.UI.BunifuThinButton2 btnRegisterRegister;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel4;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel2;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuTextBox txtRePasswordRegister;
        private Bunifu.UI.WinForms.BunifuTextBox txtPasswordRegister;
        private Bunifu.UI.WinForms.BunifuTextBox txtEMailRegister;
        private Bunifu.Framework.UI.BunifuThinButton2 btnBackRegister;
        private Bunifu.UI.WinForms.BunifuPictureBox bunifuPictureBox1;
    }
}