﻿namespace HealthLife_UI
{
    partial class UserInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserInformation));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties17 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties18 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties19 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties20 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuGradientPanel1 = new Bunifu.UI.WinForms.BunifuGradientPanel();
            this.pbUserInformation = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.pbUpdateUserInformation = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.btnDeleteUser = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnAddPhoto = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnBackUserInformation = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnUpdateProduct = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuLabel14 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel3 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel18 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel12 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel4 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel10 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel2 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel8 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel9 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel11 = new Bunifu.UI.WinForms.BunifuLabel();
            this.txtPhotoUpdateUser = new Bunifu.UI.WinForms.BunifuTextBox();
            this.lblBMI = new Bunifu.UI.WinForms.BunifuLabel();
            this.lblCity = new Bunifu.UI.WinForms.BunifuLabel();
            this.lblHeight = new Bunifu.UI.WinForms.BunifuLabel();
            this.lblWeight = new Bunifu.UI.WinForms.BunifuLabel();
            this.lblName = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel5 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel7 = new Bunifu.UI.WinForms.BunifuLabel();
            this.txtCityUpdateUser = new Bunifu.UI.WinForms.BunifuTextBox();
            this.txtHeightUpdateUser = new Bunifu.UI.WinForms.BunifuTextBox();
            this.txtWeightUpdateUser = new Bunifu.UI.WinForms.BunifuTextBox();
            this.txtNameUpdateUser = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbUserInformation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUpdateUserInformation)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.BorderRadius = 1;
            this.bunifuGradientPanel1.Controls.Add(this.pbUserInformation);
            this.bunifuGradientPanel1.Controls.Add(this.pbUpdateUserInformation);
            this.bunifuGradientPanel1.Controls.Add(this.btnDeleteUser);
            this.bunifuGradientPanel1.Controls.Add(this.btnAddPhoto);
            this.bunifuGradientPanel1.Controls.Add(this.btnBackUserInformation);
            this.bunifuGradientPanel1.Controls.Add(this.btnUpdateProduct);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel14);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel3);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel1);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel18);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel12);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel4);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel10);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel2);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel8);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel9);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel11);
            this.bunifuGradientPanel1.Controls.Add(this.txtPhotoUpdateUser);
            this.bunifuGradientPanel1.Controls.Add(this.lblBMI);
            this.bunifuGradientPanel1.Controls.Add(this.lblCity);
            this.bunifuGradientPanel1.Controls.Add(this.lblHeight);
            this.bunifuGradientPanel1.Controls.Add(this.lblWeight);
            this.bunifuGradientPanel1.Controls.Add(this.lblName);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel5);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel7);
            this.bunifuGradientPanel1.Controls.Add(this.txtCityUpdateUser);
            this.bunifuGradientPanel1.Controls.Add(this.txtHeightUpdateUser);
            this.bunifuGradientPanel1.Controls.Add(this.txtWeightUpdateUser);
            this.bunifuGradientPanel1.Controls.Add(this.txtNameUpdateUser);
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(92)))), ((int)(((byte)(188)))));
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.DeepPink;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.DodgerBlue;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(-5, -6);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1211, 810);
            this.bunifuGradientPanel1.TabIndex = 3;
            // 
            // pbUserInformation
            // 
            this.pbUserInformation.AllowFocused = false;
            this.pbUserInformation.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pbUserInformation.AutoSizeHeight = true;
            this.pbUserInformation.BorderRadius = 92;
            this.pbUserInformation.Image = ((System.Drawing.Image)(resources.GetObject("pbUserInformation.Image")));
            this.pbUserInformation.IsCircle = true;
            this.pbUserInformation.Location = new System.Drawing.Point(163, 98);
            this.pbUserInformation.Name = "pbUserInformation";
            this.pbUserInformation.Size = new System.Drawing.Size(185, 185);
            this.pbUserInformation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbUserInformation.TabIndex = 5;
            this.pbUserInformation.TabStop = false;
            this.pbUserInformation.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Circle;
            // 
            // pbUpdateUserInformation
            // 
            this.pbUpdateUserInformation.AllowFocused = false;
            this.pbUpdateUserInformation.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pbUpdateUserInformation.AutoSizeHeight = true;
            this.pbUpdateUserInformation.BorderRadius = 92;
            this.pbUpdateUserInformation.Image = ((System.Drawing.Image)(resources.GetObject("pbUpdateUserInformation.Image")));
            this.pbUpdateUserInformation.IsCircle = true;
            this.pbUpdateUserInformation.Location = new System.Drawing.Point(856, 98);
            this.pbUpdateUserInformation.Name = "pbUpdateUserInformation";
            this.pbUpdateUserInformation.Size = new System.Drawing.Size(185, 185);
            this.pbUpdateUserInformation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbUpdateUserInformation.TabIndex = 5;
            this.pbUpdateUserInformation.TabStop = false;
            this.pbUpdateUserInformation.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Circle;
            // 
            // btnDeleteUser
            // 
            this.btnDeleteUser.ActiveBorderThickness = 1;
            this.btnDeleteUser.ActiveCornerRadius = 20;
            this.btnDeleteUser.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnDeleteUser.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnDeleteUser.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnDeleteUser.BackColor = System.Drawing.Color.Transparent;
            this.btnDeleteUser.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDeleteUser.BackgroundImage")));
            this.btnDeleteUser.ButtonText = "Delete User";
            this.btnDeleteUser.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnDeleteUser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnDeleteUser.IdleBorderThickness = 2;
            this.btnDeleteUser.IdleCornerRadius = 20;
            this.btnDeleteUser.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnDeleteUser.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnDeleteUser.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnDeleteUser.Location = new System.Drawing.Point(812, 657);
            this.btnDeleteUser.Margin = new System.Windows.Forms.Padding(5);
            this.btnDeleteUser.Name = "btnDeleteUser";
            this.btnDeleteUser.Size = new System.Drawing.Size(340, 57);
            this.btnDeleteUser.TabIndex = 2;
            this.btnDeleteUser.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDeleteUser.Click += new System.EventHandler(this.btnDeleteUser_Click);
            // 
            // btnAddPhoto
            // 
            this.btnAddPhoto.ActiveBorderThickness = 1;
            this.btnAddPhoto.ActiveCornerRadius = 20;
            this.btnAddPhoto.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnAddPhoto.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnAddPhoto.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnAddPhoto.BackColor = System.Drawing.Color.Transparent;
            this.btnAddPhoto.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAddPhoto.BackgroundImage")));
            this.btnAddPhoto.ButtonText = "AddPhoto";
            this.btnAddPhoto.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnAddPhoto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnAddPhoto.IdleBorderThickness = 2;
            this.btnAddPhoto.IdleCornerRadius = 20;
            this.btnAddPhoto.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnAddPhoto.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnAddPhoto.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnAddPhoto.Location = new System.Drawing.Point(987, 600);
            this.btnAddPhoto.Margin = new System.Windows.Forms.Padding(5);
            this.btnAddPhoto.Name = "btnAddPhoto";
            this.btnAddPhoto.Size = new System.Drawing.Size(165, 57);
            this.btnAddPhoto.TabIndex = 2;
            this.btnAddPhoto.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAddPhoto.Click += new System.EventHandler(this.btnAddPhoto_Click);
            // 
            // btnBackUserInformation
            // 
            this.btnBackUserInformation.ActiveBorderThickness = 1;
            this.btnBackUserInformation.ActiveCornerRadius = 20;
            this.btnBackUserInformation.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnBackUserInformation.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnBackUserInformation.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnBackUserInformation.BackColor = System.Drawing.Color.Transparent;
            this.btnBackUserInformation.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBackUserInformation.BackgroundImage")));
            this.btnBackUserInformation.ButtonText = "Back";
            this.btnBackUserInformation.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnBackUserInformation.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnBackUserInformation.IdleBorderThickness = 2;
            this.btnBackUserInformation.IdleCornerRadius = 20;
            this.btnBackUserInformation.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnBackUserInformation.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnBackUserInformation.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnBackUserInformation.Location = new System.Drawing.Point(987, 724);
            this.btnBackUserInformation.Margin = new System.Windows.Forms.Padding(5);
            this.btnBackUserInformation.Name = "btnBackUserInformation";
            this.btnBackUserInformation.Size = new System.Drawing.Size(165, 57);
            this.btnBackUserInformation.TabIndex = 2;
            this.btnBackUserInformation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnBackUserInformation.Click += new System.EventHandler(this.btnBackUserInformation_Click);
            // 
            // btnUpdateProduct
            // 
            this.btnUpdateProduct.ActiveBorderThickness = 1;
            this.btnUpdateProduct.ActiveCornerRadius = 20;
            this.btnUpdateProduct.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdateProduct.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnUpdateProduct.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdateProduct.BackColor = System.Drawing.Color.Transparent;
            this.btnUpdateProduct.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUpdateProduct.BackgroundImage")));
            this.btnUpdateProduct.ButtonText = "Update";
            this.btnUpdateProduct.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnUpdateProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnUpdateProduct.IdleBorderThickness = 2;
            this.btnUpdateProduct.IdleCornerRadius = 20;
            this.btnUpdateProduct.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnUpdateProduct.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnUpdateProduct.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnUpdateProduct.Location = new System.Drawing.Point(812, 600);
            this.btnUpdateProduct.Margin = new System.Windows.Forms.Padding(5);
            this.btnUpdateProduct.Name = "btnUpdateProduct";
            this.btnUpdateProduct.Size = new System.Drawing.Size(165, 57);
            this.btnUpdateProduct.TabIndex = 2;
            this.btnUpdateProduct.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnUpdateProduct.Click += new System.EventHandler(this.btnUpdateProduct_Click);
            // 
            // bunifuLabel14
            // 
            this.bunifuLabel14.AllowParentOverrides = false;
            this.bunifuLabel14.AutoEllipsis = false;
            this.bunifuLabel14.AutoSize = false;
            this.bunifuLabel14.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel14.Font = new System.Drawing.Font("Monotype Corsiva", 35F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel14.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel14.Location = new System.Drawing.Point(100, 18);
            this.bunifuLabel14.Name = "bunifuLabel14";
            this.bunifuLabel14.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel14.Size = new System.Drawing.Size(465, 56);
            this.bunifuLabel14.TabIndex = 3;
            this.bunifuLabel14.Text = "User Information";
            this.bunifuLabel14.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel14.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel3
            // 
            this.bunifuLabel3.AllowParentOverrides = false;
            this.bunifuLabel3.AutoEllipsis = false;
            this.bunifuLabel3.AutoSize = false;
            this.bunifuLabel3.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel3.Font = new System.Drawing.Font("Monotype Corsiva", 35F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel3.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel3.Location = new System.Drawing.Point(733, 18);
            this.bunifuLabel3.Name = "bunifuLabel3";
            this.bunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel3.Size = new System.Drawing.Size(465, 56);
            this.bunifuLabel3.TabIndex = 3;
            this.bunifuLabel3.Text = "Update User Information";
            this.bunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AllowParentOverrides = false;
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel1.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel1.Location = new System.Drawing.Point(734, 550);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(54, 25);
            this.bunifuLabel1.TabIndex = 1;
            this.bunifuLabel1.Text = "Photo";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel18
            // 
            this.bunifuLabel18.AllowParentOverrides = false;
            this.bunifuLabel18.AutoEllipsis = false;
            this.bunifuLabel18.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel18.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel18.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel18.Location = new System.Drawing.Point(51, 538);
            this.bunifuLabel18.Name = "bunifuLabel18";
            this.bunifuLabel18.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel18.Size = new System.Drawing.Size(46, 25);
            this.bunifuLabel18.TabIndex = 1;
            this.bunifuLabel18.Text = "BMI : ";
            this.bunifuLabel18.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel18.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel12
            // 
            this.bunifuLabel12.AllowParentOverrides = false;
            this.bunifuLabel12.AutoEllipsis = false;
            this.bunifuLabel12.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel12.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel12.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel12.Location = new System.Drawing.Point(51, 492);
            this.bunifuLabel12.Name = "bunifuLabel12";
            this.bunifuLabel12.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel12.Size = new System.Drawing.Size(44, 25);
            this.bunifuLabel12.TabIndex = 1;
            this.bunifuLabel12.Text = "City : ";
            this.bunifuLabel12.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel12.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel4
            // 
            this.bunifuLabel4.AllowParentOverrides = false;
            this.bunifuLabel4.AutoEllipsis = false;
            this.bunifuLabel4.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel4.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel4.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel4.Location = new System.Drawing.Point(734, 492);
            this.bunifuLabel4.Name = "bunifuLabel4";
            this.bunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel4.Size = new System.Drawing.Size(34, 25);
            this.bunifuLabel4.TabIndex = 1;
            this.bunifuLabel4.Text = "City";
            this.bunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel4.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel10
            // 
            this.bunifuLabel10.AllowParentOverrides = false;
            this.bunifuLabel10.AutoEllipsis = false;
            this.bunifuLabel10.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel10.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel10.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel10.Location = new System.Drawing.Point(25, 434);
            this.bunifuLabel10.Name = "bunifuLabel10";
            this.bunifuLabel10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel10.Size = new System.Drawing.Size(70, 25);
            this.bunifuLabel10.TabIndex = 1;
            this.bunifuLabel10.Text = "Height : ";
            this.bunifuLabel10.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel10.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel2
            // 
            this.bunifuLabel2.AllowParentOverrides = false;
            this.bunifuLabel2.AutoEllipsis = false;
            this.bunifuLabel2.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel2.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel2.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel2.Location = new System.Drawing.Point(733, 434);
            this.bunifuLabel2.Name = "bunifuLabel2";
            this.bunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel2.Size = new System.Drawing.Size(100, 25);
            this.bunifuLabel2.TabIndex = 1;
            this.bunifuLabel2.Text = "Height(cm)";
            this.bunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel2.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel8
            // 
            this.bunifuLabel8.AllowParentOverrides = false;
            this.bunifuLabel8.AutoEllipsis = false;
            this.bunifuLabel8.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel8.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel8.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel8.Location = new System.Drawing.Point(21, 378);
            this.bunifuLabel8.Name = "bunifuLabel8";
            this.bunifuLabel8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel8.Size = new System.Drawing.Size(74, 25);
            this.bunifuLabel8.TabIndex = 1;
            this.bunifuLabel8.Text = "Weight : ";
            this.bunifuLabel8.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel8.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel9
            // 
            this.bunifuLabel9.AllowParentOverrides = false;
            this.bunifuLabel9.AutoEllipsis = false;
            this.bunifuLabel9.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel9.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel9.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel9.Location = new System.Drawing.Point(733, 378);
            this.bunifuLabel9.Name = "bunifuLabel9";
            this.bunifuLabel9.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel9.Size = new System.Drawing.Size(64, 25);
            this.bunifuLabel9.TabIndex = 1;
            this.bunifuLabel9.Text = "Weight";
            this.bunifuLabel9.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel9.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel11
            // 
            this.bunifuLabel11.AllowParentOverrides = false;
            this.bunifuLabel11.AutoEllipsis = false;
            this.bunifuLabel11.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel11.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel11.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel11.Location = new System.Drawing.Point(1027, 671);
            this.bunifuLabel11.Name = "bunifuLabel11";
            this.bunifuLabel11.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel11.Size = new System.Drawing.Size(85, 25);
            this.bunifuLabel11.TabIndex = 1;
            this.bunifuLabel11.Text = "Password";
            this.bunifuLabel11.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel11.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // txtPhotoUpdateUser
            // 
            this.txtPhotoUpdateUser.AcceptsReturn = false;
            this.txtPhotoUpdateUser.AcceptsTab = false;
            this.txtPhotoUpdateUser.AnimationSpeed = 200;
            this.txtPhotoUpdateUser.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtPhotoUpdateUser.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtPhotoUpdateUser.AutoSizeHeight = true;
            this.txtPhotoUpdateUser.BackColor = System.Drawing.Color.Transparent;
            this.txtPhotoUpdateUser.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtPhotoUpdateUser.BackgroundImage")));
            this.txtPhotoUpdateUser.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtPhotoUpdateUser.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtPhotoUpdateUser.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtPhotoUpdateUser.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtPhotoUpdateUser.BorderRadius = 1;
            this.txtPhotoUpdateUser.BorderThickness = 2;
            this.txtPhotoUpdateUser.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.txtPhotoUpdateUser.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtPhotoUpdateUser.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtPhotoUpdateUser.DefaultText = "";
            this.txtPhotoUpdateUser.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.txtPhotoUpdateUser.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.txtPhotoUpdateUser.HideSelection = true;
            this.txtPhotoUpdateUser.IconLeft = null;
            this.txtPhotoUpdateUser.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPhotoUpdateUser.IconPadding = 10;
            this.txtPhotoUpdateUser.IconRight = null;
            this.txtPhotoUpdateUser.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPhotoUpdateUser.Lines = new string[0];
            this.txtPhotoUpdateUser.Location = new System.Drawing.Point(845, 537);
            this.txtPhotoUpdateUser.MaxLength = 32767;
            this.txtPhotoUpdateUser.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtPhotoUpdateUser.Modified = false;
            this.txtPhotoUpdateUser.Multiline = false;
            this.txtPhotoUpdateUser.Name = "txtPhotoUpdateUser";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtPhotoUpdateUser.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtPhotoUpdateUser.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtPhotoUpdateUser.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            stateProperties4.ForeColor = System.Drawing.Color.DarkTurquoise;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtPhotoUpdateUser.OnIdleState = stateProperties4;
            this.txtPhotoUpdateUser.Padding = new System.Windows.Forms.Padding(3);
            this.txtPhotoUpdateUser.PasswordChar = '\0';
            this.txtPhotoUpdateUser.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtPhotoUpdateUser.PlaceholderText = "Enter text";
            this.txtPhotoUpdateUser.ReadOnly = false;
            this.txtPhotoUpdateUser.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPhotoUpdateUser.SelectedText = "";
            this.txtPhotoUpdateUser.SelectionLength = 0;
            this.txtPhotoUpdateUser.SelectionStart = 0;
            this.txtPhotoUpdateUser.ShortcutsEnabled = true;
            this.txtPhotoUpdateUser.Size = new System.Drawing.Size(319, 50);
            this.txtPhotoUpdateUser.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtPhotoUpdateUser.TabIndex = 0;
            this.txtPhotoUpdateUser.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtPhotoUpdateUser.TextMarginBottom = 0;
            this.txtPhotoUpdateUser.TextMarginLeft = 3;
            this.txtPhotoUpdateUser.TextMarginTop = 1;
            this.txtPhotoUpdateUser.TextPlaceholder = "Enter text";
            this.txtPhotoUpdateUser.UseSystemPasswordChar = false;
            this.txtPhotoUpdateUser.WordWrap = true;
            // 
            // lblBMI
            // 
            this.lblBMI.AllowParentOverrides = false;
            this.lblBMI.AutoEllipsis = false;
            this.lblBMI.CursorType = System.Windows.Forms.Cursors.Default;
            this.lblBMI.Font = new System.Drawing.Font("Segoe UI Semibold", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblBMI.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.lblBMI.Location = new System.Drawing.Point(128, 538);
            this.lblBMI.Name = "lblBMI";
            this.lblBMI.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblBMI.Size = new System.Drawing.Size(0, 0);
            this.lblBMI.TabIndex = 1;
            this.lblBMI.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.lblBMI.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // lblCity
            // 
            this.lblCity.AllowParentOverrides = false;
            this.lblCity.AutoEllipsis = false;
            this.lblCity.CursorType = System.Windows.Forms.Cursors.Default;
            this.lblCity.Font = new System.Drawing.Font("Segoe UI Semibold", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCity.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.lblCity.Location = new System.Drawing.Point(128, 492);
            this.lblCity.Name = "lblCity";
            this.lblCity.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblCity.Size = new System.Drawing.Size(0, 0);
            this.lblCity.TabIndex = 1;
            this.lblCity.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.lblCity.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // lblHeight
            // 
            this.lblHeight.AllowParentOverrides = false;
            this.lblHeight.AutoEllipsis = false;
            this.lblHeight.CursorType = System.Windows.Forms.Cursors.Default;
            this.lblHeight.Font = new System.Drawing.Font("Segoe UI Semibold", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblHeight.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.lblHeight.Location = new System.Drawing.Point(128, 434);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblHeight.Size = new System.Drawing.Size(0, 0);
            this.lblHeight.TabIndex = 1;
            this.lblHeight.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.lblHeight.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // lblWeight
            // 
            this.lblWeight.AllowParentOverrides = false;
            this.lblWeight.AutoEllipsis = false;
            this.lblWeight.CursorType = System.Windows.Forms.Cursors.Default;
            this.lblWeight.Font = new System.Drawing.Font("Segoe UI Semibold", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblWeight.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.lblWeight.Location = new System.Drawing.Point(128, 378);
            this.lblWeight.Name = "lblWeight";
            this.lblWeight.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblWeight.Size = new System.Drawing.Size(0, 0);
            this.lblWeight.TabIndex = 1;
            this.lblWeight.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.lblWeight.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // lblName
            // 
            this.lblName.AllowParentOverrides = false;
            this.lblName.AutoEllipsis = false;
            this.lblName.CursorType = System.Windows.Forms.Cursors.Default;
            this.lblName.Font = new System.Drawing.Font("Segoe UI Semibold", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblName.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.lblName.Location = new System.Drawing.Point(128, 322);
            this.lblName.Name = "lblName";
            this.lblName.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblName.Size = new System.Drawing.Size(0, 0);
            this.lblName.TabIndex = 1;
            this.lblName.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.lblName.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel5
            // 
            this.bunifuLabel5.AllowParentOverrides = false;
            this.bunifuLabel5.AutoEllipsis = false;
            this.bunifuLabel5.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel5.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel5.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel5.Location = new System.Drawing.Point(33, 322);
            this.bunifuLabel5.Name = "bunifuLabel5";
            this.bunifuLabel5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel5.Size = new System.Drawing.Size(62, 25);
            this.bunifuLabel5.TabIndex = 1;
            this.bunifuLabel5.Text = "Name : ";
            this.bunifuLabel5.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel5.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel7
            // 
            this.bunifuLabel7.AllowParentOverrides = false;
            this.bunifuLabel7.AutoEllipsis = false;
            this.bunifuLabel7.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel7.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel7.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel7.Location = new System.Drawing.Point(733, 322);
            this.bunifuLabel7.Name = "bunifuLabel7";
            this.bunifuLabel7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel7.Size = new System.Drawing.Size(52, 25);
            this.bunifuLabel7.TabIndex = 1;
            this.bunifuLabel7.Text = "Name";
            this.bunifuLabel7.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel7.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // txtCityUpdateUser
            // 
            this.txtCityUpdateUser.AcceptsReturn = false;
            this.txtCityUpdateUser.AcceptsTab = false;
            this.txtCityUpdateUser.AnimationSpeed = 200;
            this.txtCityUpdateUser.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtCityUpdateUser.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtCityUpdateUser.AutoSizeHeight = true;
            this.txtCityUpdateUser.BackColor = System.Drawing.Color.Transparent;
            this.txtCityUpdateUser.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtCityUpdateUser.BackgroundImage")));
            this.txtCityUpdateUser.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtCityUpdateUser.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtCityUpdateUser.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtCityUpdateUser.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtCityUpdateUser.BorderRadius = 1;
            this.txtCityUpdateUser.BorderThickness = 2;
            this.txtCityUpdateUser.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.txtCityUpdateUser.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtCityUpdateUser.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtCityUpdateUser.DefaultText = "";
            this.txtCityUpdateUser.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.txtCityUpdateUser.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.txtCityUpdateUser.HideSelection = true;
            this.txtCityUpdateUser.IconLeft = null;
            this.txtCityUpdateUser.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCityUpdateUser.IconPadding = 10;
            this.txtCityUpdateUser.IconRight = null;
            this.txtCityUpdateUser.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCityUpdateUser.Lines = new string[0];
            this.txtCityUpdateUser.Location = new System.Drawing.Point(845, 479);
            this.txtCityUpdateUser.MaxLength = 32767;
            this.txtCityUpdateUser.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtCityUpdateUser.Modified = false;
            this.txtCityUpdateUser.Multiline = false;
            this.txtCityUpdateUser.Name = "txtCityUpdateUser";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCityUpdateUser.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtCityUpdateUser.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCityUpdateUser.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            stateProperties8.ForeColor = System.Drawing.Color.DarkTurquoise;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCityUpdateUser.OnIdleState = stateProperties8;
            this.txtCityUpdateUser.Padding = new System.Windows.Forms.Padding(3);
            this.txtCityUpdateUser.PasswordChar = '\0';
            this.txtCityUpdateUser.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtCityUpdateUser.PlaceholderText = "Enter text";
            this.txtCityUpdateUser.ReadOnly = false;
            this.txtCityUpdateUser.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCityUpdateUser.SelectedText = "";
            this.txtCityUpdateUser.SelectionLength = 0;
            this.txtCityUpdateUser.SelectionStart = 0;
            this.txtCityUpdateUser.ShortcutsEnabled = true;
            this.txtCityUpdateUser.Size = new System.Drawing.Size(319, 50);
            this.txtCityUpdateUser.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtCityUpdateUser.TabIndex = 0;
            this.txtCityUpdateUser.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtCityUpdateUser.TextMarginBottom = 0;
            this.txtCityUpdateUser.TextMarginLeft = 3;
            this.txtCityUpdateUser.TextMarginTop = 1;
            this.txtCityUpdateUser.TextPlaceholder = "Enter text";
            this.txtCityUpdateUser.UseSystemPasswordChar = false;
            this.txtCityUpdateUser.WordWrap = true;
            // 
            // txtHeightUpdateUser
            // 
            this.txtHeightUpdateUser.AcceptsReturn = false;
            this.txtHeightUpdateUser.AcceptsTab = false;
            this.txtHeightUpdateUser.AnimationSpeed = 200;
            this.txtHeightUpdateUser.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtHeightUpdateUser.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtHeightUpdateUser.AutoSizeHeight = true;
            this.txtHeightUpdateUser.BackColor = System.Drawing.Color.Transparent;
            this.txtHeightUpdateUser.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtHeightUpdateUser.BackgroundImage")));
            this.txtHeightUpdateUser.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtHeightUpdateUser.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtHeightUpdateUser.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtHeightUpdateUser.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtHeightUpdateUser.BorderRadius = 1;
            this.txtHeightUpdateUser.BorderThickness = 2;
            this.txtHeightUpdateUser.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.txtHeightUpdateUser.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtHeightUpdateUser.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtHeightUpdateUser.DefaultText = "";
            this.txtHeightUpdateUser.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.txtHeightUpdateUser.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.txtHeightUpdateUser.HideSelection = true;
            this.txtHeightUpdateUser.IconLeft = null;
            this.txtHeightUpdateUser.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtHeightUpdateUser.IconPadding = 10;
            this.txtHeightUpdateUser.IconRight = null;
            this.txtHeightUpdateUser.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtHeightUpdateUser.Lines = new string[0];
            this.txtHeightUpdateUser.Location = new System.Drawing.Point(844, 421);
            this.txtHeightUpdateUser.MaxLength = 32767;
            this.txtHeightUpdateUser.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtHeightUpdateUser.Modified = false;
            this.txtHeightUpdateUser.Multiline = false;
            this.txtHeightUpdateUser.Name = "txtHeightUpdateUser";
            stateProperties9.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtHeightUpdateUser.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtHeightUpdateUser.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtHeightUpdateUser.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            stateProperties12.ForeColor = System.Drawing.Color.DarkTurquoise;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtHeightUpdateUser.OnIdleState = stateProperties12;
            this.txtHeightUpdateUser.Padding = new System.Windows.Forms.Padding(3);
            this.txtHeightUpdateUser.PasswordChar = '\0';
            this.txtHeightUpdateUser.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtHeightUpdateUser.PlaceholderText = "Enter text";
            this.txtHeightUpdateUser.ReadOnly = false;
            this.txtHeightUpdateUser.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtHeightUpdateUser.SelectedText = "";
            this.txtHeightUpdateUser.SelectionLength = 0;
            this.txtHeightUpdateUser.SelectionStart = 0;
            this.txtHeightUpdateUser.ShortcutsEnabled = true;
            this.txtHeightUpdateUser.Size = new System.Drawing.Size(319, 50);
            this.txtHeightUpdateUser.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtHeightUpdateUser.TabIndex = 0;
            this.txtHeightUpdateUser.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtHeightUpdateUser.TextMarginBottom = 0;
            this.txtHeightUpdateUser.TextMarginLeft = 3;
            this.txtHeightUpdateUser.TextMarginTop = 1;
            this.txtHeightUpdateUser.TextPlaceholder = "Enter text";
            this.txtHeightUpdateUser.UseSystemPasswordChar = false;
            this.txtHeightUpdateUser.WordWrap = true;
            // 
            // txtWeightUpdateUser
            // 
            this.txtWeightUpdateUser.AcceptsReturn = false;
            this.txtWeightUpdateUser.AcceptsTab = false;
            this.txtWeightUpdateUser.AnimationSpeed = 200;
            this.txtWeightUpdateUser.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtWeightUpdateUser.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtWeightUpdateUser.AutoSizeHeight = true;
            this.txtWeightUpdateUser.BackColor = System.Drawing.Color.Transparent;
            this.txtWeightUpdateUser.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtWeightUpdateUser.BackgroundImage")));
            this.txtWeightUpdateUser.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtWeightUpdateUser.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtWeightUpdateUser.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtWeightUpdateUser.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtWeightUpdateUser.BorderRadius = 1;
            this.txtWeightUpdateUser.BorderThickness = 2;
            this.txtWeightUpdateUser.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.txtWeightUpdateUser.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtWeightUpdateUser.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtWeightUpdateUser.DefaultText = "";
            this.txtWeightUpdateUser.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.txtWeightUpdateUser.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.txtWeightUpdateUser.HideSelection = true;
            this.txtWeightUpdateUser.IconLeft = null;
            this.txtWeightUpdateUser.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtWeightUpdateUser.IconPadding = 10;
            this.txtWeightUpdateUser.IconRight = null;
            this.txtWeightUpdateUser.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtWeightUpdateUser.Lines = new string[0];
            this.txtWeightUpdateUser.Location = new System.Drawing.Point(844, 365);
            this.txtWeightUpdateUser.MaxLength = 32767;
            this.txtWeightUpdateUser.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtWeightUpdateUser.Modified = false;
            this.txtWeightUpdateUser.Multiline = false;
            this.txtWeightUpdateUser.Name = "txtWeightUpdateUser";
            stateProperties13.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtWeightUpdateUser.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtWeightUpdateUser.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtWeightUpdateUser.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.Silver;
            stateProperties16.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            stateProperties16.ForeColor = System.Drawing.Color.DarkTurquoise;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtWeightUpdateUser.OnIdleState = stateProperties16;
            this.txtWeightUpdateUser.Padding = new System.Windows.Forms.Padding(3);
            this.txtWeightUpdateUser.PasswordChar = '\0';
            this.txtWeightUpdateUser.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtWeightUpdateUser.PlaceholderText = "Enter text";
            this.txtWeightUpdateUser.ReadOnly = false;
            this.txtWeightUpdateUser.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtWeightUpdateUser.SelectedText = "";
            this.txtWeightUpdateUser.SelectionLength = 0;
            this.txtWeightUpdateUser.SelectionStart = 0;
            this.txtWeightUpdateUser.ShortcutsEnabled = true;
            this.txtWeightUpdateUser.Size = new System.Drawing.Size(319, 50);
            this.txtWeightUpdateUser.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtWeightUpdateUser.TabIndex = 0;
            this.txtWeightUpdateUser.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtWeightUpdateUser.TextMarginBottom = 0;
            this.txtWeightUpdateUser.TextMarginLeft = 3;
            this.txtWeightUpdateUser.TextMarginTop = 1;
            this.txtWeightUpdateUser.TextPlaceholder = "Enter text";
            this.txtWeightUpdateUser.UseSystemPasswordChar = false;
            this.txtWeightUpdateUser.WordWrap = true;
            // 
            // txtNameUpdateUser
            // 
            this.txtNameUpdateUser.AcceptsReturn = false;
            this.txtNameUpdateUser.AcceptsTab = false;
            this.txtNameUpdateUser.AnimationSpeed = 200;
            this.txtNameUpdateUser.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtNameUpdateUser.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtNameUpdateUser.AutoSizeHeight = true;
            this.txtNameUpdateUser.BackColor = System.Drawing.Color.Transparent;
            this.txtNameUpdateUser.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtNameUpdateUser.BackgroundImage")));
            this.txtNameUpdateUser.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtNameUpdateUser.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtNameUpdateUser.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtNameUpdateUser.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtNameUpdateUser.BorderRadius = 1;
            this.txtNameUpdateUser.BorderThickness = 2;
            this.txtNameUpdateUser.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.txtNameUpdateUser.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtNameUpdateUser.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtNameUpdateUser.DefaultText = "";
            this.txtNameUpdateUser.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.txtNameUpdateUser.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.txtNameUpdateUser.HideSelection = true;
            this.txtNameUpdateUser.IconLeft = null;
            this.txtNameUpdateUser.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNameUpdateUser.IconPadding = 10;
            this.txtNameUpdateUser.IconRight = null;
            this.txtNameUpdateUser.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNameUpdateUser.Lines = new string[0];
            this.txtNameUpdateUser.Location = new System.Drawing.Point(844, 309);
            this.txtNameUpdateUser.MaxLength = 32767;
            this.txtNameUpdateUser.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtNameUpdateUser.Modified = false;
            this.txtNameUpdateUser.Multiline = false;
            this.txtNameUpdateUser.Name = "txtNameUpdateUser";
            stateProperties17.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties17.FillColor = System.Drawing.Color.Empty;
            stateProperties17.ForeColor = System.Drawing.Color.Empty;
            stateProperties17.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNameUpdateUser.OnActiveState = stateProperties17;
            stateProperties18.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties18.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties18.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtNameUpdateUser.OnDisabledState = stateProperties18;
            stateProperties19.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties19.FillColor = System.Drawing.Color.Empty;
            stateProperties19.ForeColor = System.Drawing.Color.Empty;
            stateProperties19.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNameUpdateUser.OnHoverState = stateProperties19;
            stateProperties20.BorderColor = System.Drawing.Color.Silver;
            stateProperties20.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            stateProperties20.ForeColor = System.Drawing.Color.DarkTurquoise;
            stateProperties20.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNameUpdateUser.OnIdleState = stateProperties20;
            this.txtNameUpdateUser.Padding = new System.Windows.Forms.Padding(3);
            this.txtNameUpdateUser.PasswordChar = '\0';
            this.txtNameUpdateUser.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtNameUpdateUser.PlaceholderText = "Enter text";
            this.txtNameUpdateUser.ReadOnly = false;
            this.txtNameUpdateUser.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtNameUpdateUser.SelectedText = "";
            this.txtNameUpdateUser.SelectionLength = 0;
            this.txtNameUpdateUser.SelectionStart = 0;
            this.txtNameUpdateUser.ShortcutsEnabled = true;
            this.txtNameUpdateUser.Size = new System.Drawing.Size(319, 50);
            this.txtNameUpdateUser.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtNameUpdateUser.TabIndex = 0;
            this.txtNameUpdateUser.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtNameUpdateUser.TextMarginBottom = 0;
            this.txtNameUpdateUser.TextMarginLeft = 3;
            this.txtNameUpdateUser.TextMarginTop = 1;
            this.txtNameUpdateUser.TextPlaceholder = "Enter text";
            this.txtNameUpdateUser.UseSystemPasswordChar = false;
            this.txtNameUpdateUser.WordWrap = true;
            // 
            // UserInformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 800);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "UserInformation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UserInformation";
            this.Load += new System.EventHandler(this.UserInformation_Load);
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbUserInformation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUpdateUserInformation)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.UI.WinForms.BunifuPictureBox pbUpdateUserInformation;
        private Bunifu.Framework.UI.BunifuThinButton2 btnDeleteUser;
        private Bunifu.Framework.UI.BunifuThinButton2 btnAddPhoto;
        private Bunifu.Framework.UI.BunifuThinButton2 btnUpdateProduct;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel3;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel9;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel11;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel7;
        private Bunifu.UI.WinForms.BunifuTextBox txtCityUpdateUser;
        private Bunifu.UI.WinForms.BunifuTextBox txtWeightUpdateUser;
        private Bunifu.UI.WinForms.BunifuTextBox txtNameUpdateUser;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel2;
        private Bunifu.UI.WinForms.BunifuTextBox txtHeightUpdateUser;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel4;
        private Bunifu.UI.WinForms.BunifuTextBox txtPhotoUpdateUser;
        private Bunifu.UI.WinForms.BunifuPictureBox pbUserInformation;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel14;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel18;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel12;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel10;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel8;
        private Bunifu.UI.WinForms.BunifuLabel lblBMI;
        private Bunifu.UI.WinForms.BunifuLabel lblCity;
        private Bunifu.UI.WinForms.BunifuLabel lblHeight;
        private Bunifu.UI.WinForms.BunifuLabel lblWeight;
        private Bunifu.UI.WinForms.BunifuLabel lblName;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel5;
        private Bunifu.Framework.UI.BunifuThinButton2 btnBackUserInformation;
    }
}