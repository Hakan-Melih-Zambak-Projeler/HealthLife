﻿using Bunifu.Framework.UI;
using HealthLife_BLL.Controllers;
using HealthLife_Model.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthLife_UI
{
    public partial class AddMeal : Form
    {
        public AddMeal()
        {
            InitializeComponent();
        }

        private void AddMeal_Load(object sender, EventArgs e)
        {
            ddCategoryMeal.DataSource = CategoryController.GetCategories();
            ddCategoryMeal.DisplayMember= "Name";          
            ddProduct.DataSource = ProductController.GetProducts();
            ddProduct.DisplayMember= "Name";
            dgvMeal.DataSource = MealController.GetMeals();
            ddProduct.Enabled = false;


        }
        //OpenFileDialog fileDialog = new OpenFileDialog();
        //DialogResult dialogResult = fileDialog.ShowDialog();
        //if (dialogResult == DialogResult.OK)
        //{
        //    tbImagePath.Text = fileDialog.FileName;
        //}      
        private void btnAddMeal_Click(object sender, EventArgs e)
        {
            if (ddMeal.SelectedItem != null)
            {
                Meal meal = new Meal();
                meal.Name = ddMeal.SelectedItem.ToString();
                meal.Date = dpDatePicker.Value;
                meal.UserId = UserController.LoginedUserID;
                MealController.AddMealbyUser(meal);
                dgvMeal.DataSource = MealController.GetMeals();
            }
            else
            {
                return;
            }

        }

        private void btnUpdateMeal_Click(object sender, EventArgs e)
        {
            if (dgvMeal.SelectedRows[0].Cells[0].Value != null && ddMeal.SelectedItem != null)
            {
                int mealID = Convert.ToInt32(dgvMeal.SelectedRows[0].Cells[0].Value);
                Meal meal = MealController.GetMealByID(mealID);
                meal.Name = ddMeal.SelectedItem.ToString();
                meal.Date = dpDatePicker.Value;                
                MealController.UpdateMeal(meal);
                dgvMeal.DataSource = MealController.GetMeals();
            }
            else
            {
                return;
            }
        }

        private void bunifuGradientPanel1_Click(object sender, EventArgs e)
        {

        }

        private void btnDeleteMeal_Click(object sender, EventArgs e)
        {
            int mealID = Convert.ToInt32(dgvMeal.SelectedRows[0].Cells[0].Value);
            Meal meal = MealController.GetMealByID(mealID);
            MealController.RemoveMeal(meal);
            dgvMeal.DataSource = MealController.GetMeals();
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            if (ddCategoryMeal.SelectedItem != null && ddProduct.SelectedItem != null && dgvMeal.SelectedRows != null && txtPortion.Text != "")
            {
                Product selectedProduct = ddProduct.SelectedItem as Product;
                Meal meal = dgvMeal.SelectedRows[0].DataBoundItem as Meal;
                meal.MealProducts.Add(new MealProduct { PortionAmount = Convert.ToDouble(txtPortion.Text), MealId = meal.Id, ProductId = selectedProduct.Id});
                MealController.UpdateMeal(meal);               
                dgwProducts.DataSource = MealController.GetMealProducts(meal.Id);                
            }
            else
            {
                MessageBox.Show("Please fill the all information");
            }
        }

        private void ddCategoryMeal_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddCategoryMeal.SelectedItem is Category category)
            {
                ddProduct.DataSource = ProductController.GetProductsByCategory(category.Id);
                ddProduct.Enabled = true;
            }     
        }

        private void ddProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            Image image;
            Product selectedProduct = ddProduct.SelectedItem as Product;
            if (selectedProduct.Photo !=null)
            {
                using (MemoryStream stream = new MemoryStream(selectedProduct.Photo))
                {                   
                    image = Image.FromStream(stream);
                } 
                pbProduct.Image = image;
                pbProduct.Visible= true;
            }
            else
            {
                pbProduct.Visible = false;
            }
            
        }

        private void btnUpdateProduct_Click(object sender, EventArgs e)
        {
            if (ddCategoryMeal.SelectedItem != null && ddProduct.SelectedItem != null && dgvMeal.SelectedRows != null)
            {
                
                Meal meal = dgvMeal.SelectedRows[0].DataBoundItem as Meal;
                MealProduct mealProduct = dgwProducts.SelectedRows[0].DataBoundItem as MealProduct;
                mealProduct.PortionAmount = Convert.ToDouble(txtPortion.Text);
                MealController.UpdateMealProduct(mealProduct);
                dgwProducts.DataSource = MealController.GetMealProducts(meal.Id);
            }
            else
            {
                return;
            }
        }

        private void btnDeleteProduct_Click(object sender, EventArgs e)
        {
            if (dgwProducts.SelectedRows.Count > 0 && dgvMeal.SelectedRows != null)
            {
                Meal meal = dgvMeal.SelectedRows[0].DataBoundItem as Meal;
                MealProduct mealProduct = dgwProducts.SelectedRows[0].DataBoundItem as MealProduct;
                MealController.DeleteProductFromMeal(mealProduct);
                dgwProducts.DataSource = MealController.GetMealProducts(meal.Id);
            }
            else
            {
                MessageBox.Show("Please choose product,which one you want delete.");
            }
        }

        private void dgvMeal_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvMeal.SelectedRows.Count>0)
            {
                Meal meal = dgvMeal.SelectedRows[0].DataBoundItem as Meal;
                dgwProducts.DataSource = MealController.GetMealProducts(meal.Id);
            }
            else
            {

            }
        }

        private void btnBackAddMeal_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
