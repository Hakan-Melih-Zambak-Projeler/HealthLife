﻿namespace HealthLife_UI
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderEdges borderEdges3 = new Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderEdges borderEdges4 = new Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderEdges();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuGradientPanel1 = new Bunifu.UI.WinForms.BunifuGradientPanel();
            this.bunifuLabel4 = new Bunifu.UI.WinForms.BunifuLabel();
            this.btnLogOutMain = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuPictureBox1 = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.bunifuShadowPanel1 = new Bunifu.UI.WinForms.BunifuShadowPanel();
            this.btnUserInformation = new Bunifu.UI.WinForms.BunifuButton.BunifuIconButton();
            this.bunifuLabel2 = new Bunifu.UI.WinForms.BunifuLabel();
            this.btnReports = new Bunifu.UI.WinForms.BunifuButton.BunifuIconButton();
            this.bunifuLabel6 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuIconButton1 = new Bunifu.UI.WinForms.BunifuButton.BunifuIconButton();
            this.bunifuLabel3 = new Bunifu.UI.WinForms.BunifuLabel();
            this.btnAddMeal = new Bunifu.UI.WinForms.BunifuButton.BunifuIconButton();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuPictureBox1)).BeginInit();
            this.bunifuShadowPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.BorderRadius = 1;
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel4);
            this.bunifuGradientPanel1.Controls.Add(this.btnLogOutMain);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuPictureBox1);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuShadowPanel1);
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(92)))), ((int)(((byte)(188)))));
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.DeepPink;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.DodgerBlue;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(-6, -4);
            this.bunifuGradientPanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1385, 1076);
            this.bunifuGradientPanel1.TabIndex = 2;
            // 
            // bunifuLabel4
            // 
            this.bunifuLabel4.AllowParentOverrides = false;
            this.bunifuLabel4.AutoEllipsis = false;
            this.bunifuLabel4.AutoSize = false;
            this.bunifuLabel4.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel4.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel4.Location = new System.Drawing.Point(776, 328);
            this.bunifuLabel4.Name = "bunifuLabel4";
            this.bunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel4.Size = new System.Drawing.Size(490, 456);
            this.bunifuLabel4.TabIndex = 8;
            this.bunifuLabel4.Text = resources.GetString("bunifuLabel4.Text");
            this.bunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel4.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // btnLogOutMain
            // 
            this.btnLogOutMain.ActiveBorderThickness = 1;
            this.btnLogOutMain.ActiveCornerRadius = 20;
            this.btnLogOutMain.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnLogOutMain.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnLogOutMain.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnLogOutMain.BackColor = System.Drawing.Color.Transparent;
            this.btnLogOutMain.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLogOutMain.BackgroundImage")));
            this.btnLogOutMain.ButtonText = "Logout";
            this.btnLogOutMain.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnLogOutMain.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnLogOutMain.IdleBorderThickness = 2;
            this.btnLogOutMain.IdleCornerRadius = 20;
            this.btnLogOutMain.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnLogOutMain.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnLogOutMain.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnLogOutMain.Location = new System.Drawing.Point(1147, 976);
            this.btnLogOutMain.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.btnLogOutMain.Name = "btnLogOutMain";
            this.btnLogOutMain.Size = new System.Drawing.Size(189, 76);
            this.btnLogOutMain.TabIndex = 6;
            this.btnLogOutMain.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnLogOutMain.Click += new System.EventHandler(this.btnLogOutMain_Click);
            // 
            // bunifuPictureBox1
            // 
            this.bunifuPictureBox1.AllowFocused = false;
            this.bunifuPictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuPictureBox1.AutoSizeHeight = true;
            this.bunifuPictureBox1.BorderRadius = 0;
            this.bunifuPictureBox1.Image = global::HealthLife_UI.Properties.Resources.Company_logo_21;
            this.bunifuPictureBox1.IsCircle = false;
            this.bunifuPictureBox1.Location = new System.Drawing.Point(130, 269);
            this.bunifuPictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuPictureBox1.Name = "bunifuPictureBox1";
            this.bunifuPictureBox1.Size = new System.Drawing.Size(502, 502);
            this.bunifuPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuPictureBox1.TabIndex = 6;
            this.bunifuPictureBox1.TabStop = false;
            this.bunifuPictureBox1.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Square;
            // 
            // bunifuShadowPanel1
            // 
            this.bunifuShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuShadowPanel1.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuShadowPanel1.BorderRadius = 2;
            this.bunifuShadowPanel1.BorderThickness = 2;
            this.bunifuShadowPanel1.Controls.Add(this.btnUserInformation);
            this.bunifuShadowPanel1.Controls.Add(this.bunifuLabel2);
            this.bunifuShadowPanel1.Controls.Add(this.btnReports);
            this.bunifuShadowPanel1.Controls.Add(this.bunifuLabel6);
            this.bunifuShadowPanel1.Controls.Add(this.bunifuIconButton1);
            this.bunifuShadowPanel1.Controls.Add(this.bunifuLabel3);
            this.bunifuShadowPanel1.Controls.Add(this.btnAddMeal);
            this.bunifuShadowPanel1.Controls.Add(this.bunifuLabel1);
            this.bunifuShadowPanel1.FillStyle = Bunifu.UI.WinForms.BunifuShadowPanel.FillStyles.Solid;
            this.bunifuShadowPanel1.GradientMode = Bunifu.UI.WinForms.BunifuShadowPanel.GradientModes.Vertical;
            this.bunifuShadowPanel1.Location = new System.Drawing.Point(-9, -9);
            this.bunifuShadowPanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuShadowPanel1.Name = "bunifuShadowPanel1";
            this.bunifuShadowPanel1.PanelColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(92)))), ((int)(((byte)(188)))));
            this.bunifuShadowPanel1.PanelColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(92)))), ((int)(((byte)(188)))));
            this.bunifuShadowPanel1.ShadowColor = System.Drawing.Color.DodgerBlue;
            this.bunifuShadowPanel1.ShadowDept = 2;
            this.bunifuShadowPanel1.ShadowDepth = 5;
            this.bunifuShadowPanel1.ShadowStyle = Bunifu.UI.WinForms.BunifuShadowPanel.ShadowStyles.Surrounded;
            this.bunifuShadowPanel1.ShadowTopLeftVisible = false;
            this.bunifuShadowPanel1.Size = new System.Drawing.Size(1394, 135);
            this.bunifuShadowPanel1.Style = Bunifu.UI.WinForms.BunifuShadowPanel.BevelStyles.Flat;
            this.bunifuShadowPanel1.TabIndex = 4;
            // 
            // btnUserInformation
            // 
            this.btnUserInformation.AllowAnimations = true;
            this.btnUserInformation.AllowBorderColorChanges = true;
            this.btnUserInformation.AllowMouseEffects = true;
            this.btnUserInformation.AnimationSpeed = 200;
            this.btnUserInformation.BackColor = System.Drawing.Color.Transparent;
            this.btnUserInformation.BackgroundColor = System.Drawing.Color.DarkTurquoise;
            this.btnUserInformation.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnUserInformation.BorderRadius = 1;
            this.btnUserInformation.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderStyles.Solid;
            this.btnUserInformation.BorderThickness = 1;
            this.btnUserInformation.ColorContrastOnClick = 30;
            this.btnUserInformation.ColorContrastOnHover = 30;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.btnUserInformation.CustomizableEdges = borderEdges1;
            this.btnUserInformation.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnUserInformation.Image = global::HealthLife_UI.Properties.Resources.User_Information;
            this.btnUserInformation.ImageMargin = new System.Windows.Forms.Padding(0);
            this.btnUserInformation.Location = new System.Drawing.Point(839, 13);
            this.btnUserInformation.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnUserInformation.Name = "btnUserInformation";
            this.btnUserInformation.RoundBorders = true;
            this.btnUserInformation.ShowBorders = true;
            this.btnUserInformation.Size = new System.Drawing.Size(61, 61);
            this.btnUserInformation.Style = Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.ButtonStyles.Round;
            this.btnUserInformation.TabIndex = 5;
            this.btnUserInformation.Click += new System.EventHandler(this.btnUserInformation_Click);
            // 
            // bunifuLabel2
            // 
            this.bunifuLabel2.AllowParentOverrides = false;
            this.bunifuLabel2.AutoEllipsis = false;
            this.bunifuLabel2.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel2.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel2.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel2.Location = new System.Drawing.Point(785, 92);
            this.bunifuLabel2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuLabel2.Name = "bunifuLabel2";
            this.bunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel2.Size = new System.Drawing.Size(184, 31);
            this.bunifuLabel2.TabIndex = 1;
            this.bunifuLabel2.Text = "User Information";
            this.bunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel2.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // btnReports
            // 
            this.btnReports.AllowAnimations = true;
            this.btnReports.AllowBorderColorChanges = true;
            this.btnReports.AllowMouseEffects = true;
            this.btnReports.AnimationSpeed = 200;
            this.btnReports.BackColor = System.Drawing.Color.Transparent;
            this.btnReports.BackgroundColor = System.Drawing.Color.DarkTurquoise;
            this.btnReports.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnReports.BorderRadius = 1;
            this.btnReports.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderStyles.Solid;
            this.btnReports.BorderThickness = 1;
            this.btnReports.ColorContrastOnClick = 30;
            this.btnReports.ColorContrastOnHover = 30;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.btnReports.CustomizableEdges = borderEdges2;
            this.btnReports.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnReports.Image = global::HealthLife_UI.Properties.Resources.Document;
            this.btnReports.ImageMargin = new System.Windows.Forms.Padding(0);
            this.btnReports.Location = new System.Drawing.Point(1200, 13);
            this.btnReports.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnReports.Name = "btnReports";
            this.btnReports.RoundBorders = true;
            this.btnReports.ShowBorders = true;
            this.btnReports.Size = new System.Drawing.Size(61, 61);
            this.btnReports.Style = Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.ButtonStyles.Round;
            this.btnReports.TabIndex = 5;
            this.btnReports.Click += new System.EventHandler(this.btnReports_Click);
            // 
            // bunifuLabel6
            // 
            this.bunifuLabel6.AllowParentOverrides = false;
            this.bunifuLabel6.AutoEllipsis = false;
            this.bunifuLabel6.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel6.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel6.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel6.Location = new System.Drawing.Point(1194, 92);
            this.bunifuLabel6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuLabel6.Name = "bunifuLabel6";
            this.bunifuLabel6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel6.Size = new System.Drawing.Size(83, 31);
            this.bunifuLabel6.TabIndex = 1;
            this.bunifuLabel6.Text = "Reports";
            this.bunifuLabel6.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel6.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuIconButton1
            // 
            this.bunifuIconButton1.AllowAnimations = true;
            this.bunifuIconButton1.AllowBorderColorChanges = true;
            this.bunifuIconButton1.AllowMouseEffects = true;
            this.bunifuIconButton1.AnimationSpeed = 200;
            this.bunifuIconButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuIconButton1.BackgroundColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuIconButton1.BorderColor = System.Drawing.Color.DodgerBlue;
            this.bunifuIconButton1.BorderRadius = 1;
            this.bunifuIconButton1.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderStyles.Solid;
            this.bunifuIconButton1.BorderThickness = 1;
            this.bunifuIconButton1.ColorContrastOnClick = 30;
            this.bunifuIconButton1.ColorContrastOnHover = 30;
            borderEdges3.BottomLeft = true;
            borderEdges3.BottomRight = true;
            borderEdges3.TopLeft = true;
            borderEdges3.TopRight = true;
            this.bunifuIconButton1.CustomizableEdges = borderEdges3;
            this.bunifuIconButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuIconButton1.Image = global::HealthLife_UI.Properties.Resources.Add_Product;
            this.bunifuIconButton1.ImageMargin = new System.Windows.Forms.Padding(0);
            this.bunifuIconButton1.Location = new System.Drawing.Point(466, 13);
            this.bunifuIconButton1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuIconButton1.Name = "bunifuIconButton1";
            this.bunifuIconButton1.RoundBorders = true;
            this.bunifuIconButton1.ShowBorders = true;
            this.bunifuIconButton1.Size = new System.Drawing.Size(61, 61);
            this.bunifuIconButton1.Style = Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.ButtonStyles.Round;
            this.bunifuIconButton1.TabIndex = 5;
            this.bunifuIconButton1.Click += new System.EventHandler(this.bunifuIconButton1_Click);
            // 
            // bunifuLabel3
            // 
            this.bunifuLabel3.AllowParentOverrides = false;
            this.bunifuLabel3.AutoEllipsis = false;
            this.bunifuLabel3.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel3.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel3.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel3.Location = new System.Drawing.Point(431, 92);
            this.bunifuLabel3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuLabel3.Name = "bunifuLabel3";
            this.bunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel3.Size = new System.Drawing.Size(135, 31);
            this.bunifuLabel3.TabIndex = 1;
            this.bunifuLabel3.Text = "Add Product";
            this.bunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // btnAddMeal
            // 
            this.btnAddMeal.AllowAnimations = true;
            this.btnAddMeal.AllowBorderColorChanges = true;
            this.btnAddMeal.AllowMouseEffects = true;
            this.btnAddMeal.AnimationSpeed = 200;
            this.btnAddMeal.BackColor = System.Drawing.Color.Transparent;
            this.btnAddMeal.BackgroundColor = System.Drawing.Color.DarkTurquoise;
            this.btnAddMeal.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnAddMeal.BorderRadius = 1;
            this.btnAddMeal.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.BorderStyles.Solid;
            this.btnAddMeal.BorderThickness = 1;
            this.btnAddMeal.ColorContrastOnClick = 30;
            this.btnAddMeal.ColorContrastOnHover = 30;
            borderEdges4.BottomLeft = true;
            borderEdges4.BottomRight = true;
            borderEdges4.TopLeft = true;
            borderEdges4.TopRight = true;
            this.btnAddMeal.CustomizableEdges = borderEdges4;
            this.btnAddMeal.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnAddMeal.Image = global::HealthLife_UI.Properties.Resources.Add_Meal;
            this.btnAddMeal.ImageMargin = new System.Windows.Forms.Padding(0);
            this.btnAddMeal.Location = new System.Drawing.Point(114, 13);
            this.btnAddMeal.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAddMeal.Name = "btnAddMeal";
            this.btnAddMeal.RoundBorders = true;
            this.btnAddMeal.ShowBorders = true;
            this.btnAddMeal.Size = new System.Drawing.Size(61, 61);
            this.btnAddMeal.Style = Bunifu.UI.WinForms.BunifuButton.BunifuIconButton.ButtonStyles.Round;
            this.btnAddMeal.TabIndex = 5;
            this.btnAddMeal.Click += new System.EventHandler(this.btnAddMeal_Click);
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AllowParentOverrides = false;
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel1.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel1.Location = new System.Drawing.Point(101, 92);
            this.bunifuLabel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(103, 31);
            this.bunifuLabel1.TabIndex = 1;
            this.bunifuLabel1.Text = "Add Meal";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1371, 1067);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main";
            this.bunifuGradientPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bunifuPictureBox1)).EndInit();
            this.bunifuShadowPanel1.ResumeLayout(false);
            this.bunifuShadowPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuShadowPanel bunifuShadowPanel1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuIconButton btnReports;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel6;
        private Bunifu.UI.WinForms.BunifuButton.BunifuIconButton btnAddMeal;
        private Bunifu.UI.WinForms.BunifuButton.BunifuIconButton btnUserInformation;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel2;
        private Bunifu.UI.WinForms.BunifuPictureBox bunifuPictureBox1;
        private Bunifu.Framework.UI.BunifuThinButton2 btnLogOutMain;
        private Bunifu.UI.WinForms.BunifuButton.BunifuIconButton bunifuIconButton1;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel3;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel4;
    }
}