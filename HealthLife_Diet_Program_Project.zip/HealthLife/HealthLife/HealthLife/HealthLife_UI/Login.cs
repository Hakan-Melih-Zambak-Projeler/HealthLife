using HealthLife_BLL.Controllers;
using HealthLife_Model.Models;

namespace HealthLife_UI
{
    public partial class Login : Form
    {
        
        public Login()
        {
            InitializeComponent();
        }

        private void btnRegisterLogin_Click(object sender, EventArgs e)
        {
            Register r1 = new Register();                    
            r1.ShowDialog();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            int loginedUserID = UserController.GetUserID(txtEMailLogin.Text, txtPasswordLogin.Text);
            if (loginedUserID>0)
            {
                UserController.LoginedUserID =loginedUserID;
                MessageBox.Show("Login is Successful.");
                this.Hide();
                Main main= new Main();
                main.ShowDialog();
            }
            else
            {
                MessageBox.Show("Password is not correct!");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {            
            Application.Exit();
        }

        private void bunifuGradientPanel1_Click(object sender, EventArgs e)
        {

        }
    }
}