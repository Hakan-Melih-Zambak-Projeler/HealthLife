﻿using HealthLife_BLL.Controllers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthLife_UI
{
    public partial class Reports : Form
    {
        public Reports()
        {
            InitializeComponent();
        }

        public void GetDailyReport()
        {
            var dailyReport = from mp in MealController.GetMealProductsWithCalories()
                              join m in MealController.GetMeals() on mp.MealId equals m.Id
                              join p in ProductController.GetProducts() on mp.ProductId equals p.Id
                              where m.Date.ToShortDateString() == DateTime.Now.ToShortDateString()
                              group mp by mp.Meal into mealName
                              select new { Meal = mealName.Key.Name, TotalCalorieForMeal = mealName.Sum(c => (c.PortionAmount / 100) * (c.Product.UnitCalorie)) };
            dgvDailyReport.DataSource = dailyReport.ToList();
        }

        public void GetWeeklyReport()
        {
            var weeklyReport = from mp in MealController.GetMealProductsWithCalories()
                               join m in MealController.GetMeals() on mp.MealId equals m.Id
                               join p in ProductController.GetProducts() on mp.ProductId equals p.Id
                               where m.Date <= DateTime.Now && m.Date > DateTime.Now.AddDays(-7)
                               group mp by mp.Meal into mealName
                               select new { Meal = mealName.Key.Name, AverageCalorieForMeal = mealName.Sum(c => (c.PortionAmount / 100) * (c.Product.UnitCalorie)) / mealName.Count() };
            dgvDailyReport.DataSource = weeklyReport.ToList();
        }

        public void GetMonthlyReport()
        {
            var monthlyReport = from mp in MealController.GetMealProductsWithCalories()
                                join m in MealController.GetMeals() on mp.MealId equals m.Id
                                join p in ProductController.GetProducts() on mp.ProductId equals p.Id
                                where m.Date <= DateTime.Now && m.Date > DateTime.Now.AddDays(-30)
                                group mp by mp.Meal into mealName
                                select new { Meal = mealName.Key.Name, AverageCalorieForMeal = mealName.Sum(c => (c.PortionAmount / 100) * (c.Product.UnitCalorie)) / mealName.Count() };
            dgvDailyReport.DataSource = monthlyReport.ToList();
        }

        public void FoodTypeReport()
        {
            var foodTypeReport = from mp in MealController.GetMealProductsWithCalories()
                                 join m in MealController.GetMeals() on mp.MealId equals m.Id
                                 join p in ProductController.GetProducts() on mp.ProductId equals p.Id
                                 group mp by new { ProductName = mp.Product.Name, MealName = mp.Meal.Name } into mealProductName
                                 orderby mealProductName.Count() descending
                                 select new { Meal = mealProductName.Key.MealName, Product = mealProductName.Key.ProductName, ProductCount = mealProductName.Count() };
            dgvDailyReport.DataSource = foodTypeReport.ToList();
        }

        private void btnBackReports_Click(object sender, EventArgs e)
        {
            this.Hide();
            Main main = new Main();
            main.ShowDialog();
        }

        private void ddReportType_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            switch (ddReportType.SelectedIndex)
            {
                case 0:
                    GetDailyReport();
                    break;
                case 1:
                    GetWeeklyReport();
                    break;
                case 2:
                    GetMonthlyReport();
                    break;
                case 3:
                    FoodTypeReport();
                    break;
            }
        }
    }
}
