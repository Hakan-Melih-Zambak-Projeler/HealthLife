﻿namespace HealthLife_UI
{
    partial class AddMeal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddMeal));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuGradientPanel1 = new Bunifu.UI.WinForms.BunifuGradientPanel();
            this.pbProduct = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.dpDatePicker = new Bunifu.UI.WinForms.BunifuDatePicker();
            this.dgwProducts = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.dgvMeal = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.ddMeal = new Bunifu.UI.WinForms.BunifuDropdown();
            this.ddProduct = new Bunifu.UI.WinForms.BunifuDropdown();
            this.ddCategoryMeal = new Bunifu.UI.WinForms.BunifuDropdown();
            this.bunifuLabel8 = new Bunifu.UI.WinForms.BunifuLabel();
            this.btnDeleteProduct = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnBackAddMeal = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnUpdateProduct = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuLabel3 = new Bunifu.UI.WinForms.BunifuLabel();
            this.btnAddProduct = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnUpdateMeal = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnDeleteMeal = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnAddMeal = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuLabel4 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel13 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel12 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel5 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.txtPortion = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbProduct)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgwProducts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMeal)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.BorderRadius = 1;
            this.bunifuGradientPanel1.Controls.Add(this.pbProduct);
            this.bunifuGradientPanel1.Controls.Add(this.dpDatePicker);
            this.bunifuGradientPanel1.Controls.Add(this.dgwProducts);
            this.bunifuGradientPanel1.Controls.Add(this.dgvMeal);
            this.bunifuGradientPanel1.Controls.Add(this.ddMeal);
            this.bunifuGradientPanel1.Controls.Add(this.ddProduct);
            this.bunifuGradientPanel1.Controls.Add(this.ddCategoryMeal);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel8);
            this.bunifuGradientPanel1.Controls.Add(this.btnDeleteProduct);
            this.bunifuGradientPanel1.Controls.Add(this.btnBackAddMeal);
            this.bunifuGradientPanel1.Controls.Add(this.btnUpdateProduct);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel3);
            this.bunifuGradientPanel1.Controls.Add(this.btnAddProduct);
            this.bunifuGradientPanel1.Controls.Add(this.btnUpdateMeal);
            this.bunifuGradientPanel1.Controls.Add(this.btnDeleteMeal);
            this.bunifuGradientPanel1.Controls.Add(this.btnAddMeal);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel4);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel13);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel12);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel5);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel1);
            this.bunifuGradientPanel1.Controls.Add(this.txtPortion);
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(92)))), ((int)(((byte)(188)))));
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.DeepPink;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.DodgerBlue;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(-4, -6);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1208, 809);
            this.bunifuGradientPanel1.TabIndex = 2;
            this.bunifuGradientPanel1.Click += new System.EventHandler(this.bunifuGradientPanel1_Click);
            // 
            // pbProduct
            // 
            this.pbProduct.AllowFocused = false;
            this.pbProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pbProduct.AutoSizeHeight = true;
            this.pbProduct.BorderRadius = 65;
            this.pbProduct.Image = ((System.Drawing.Image)(resources.GetObject("pbProduct.Image")));
            this.pbProduct.IsCircle = true;
            this.pbProduct.Location = new System.Drawing.Point(298, 251);
            this.pbProduct.Name = "pbProduct";
            this.pbProduct.Size = new System.Drawing.Size(131, 131);
            this.pbProduct.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbProduct.TabIndex = 7;
            this.pbProduct.TabStop = false;
            this.pbProduct.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Circle;
            this.pbProduct.Visible = false;
            // 
            // dpDatePicker
            // 
            this.dpDatePicker.BackColor = System.Drawing.Color.Transparent;
            this.dpDatePicker.BorderColor = System.Drawing.Color.Silver;
            this.dpDatePicker.BorderRadius = 1;
            this.dpDatePicker.Color = System.Drawing.Color.Silver;
            this.dpDatePicker.DateBorderThickness = Bunifu.UI.WinForms.BunifuDatePicker.BorderThickness.Thin;
            this.dpDatePicker.DateTextAlign = Bunifu.UI.WinForms.BunifuDatePicker.TextAlign.Left;
            this.dpDatePicker.DisabledColor = System.Drawing.Color.Gray;
            this.dpDatePicker.DisplayWeekNumbers = false;
            this.dpDatePicker.DPHeight = 0;
            this.dpDatePicker.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dpDatePicker.FillDatePicker = false;
            this.dpDatePicker.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dpDatePicker.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.dpDatePicker.Icon = ((System.Drawing.Image)(resources.GetObject("dpDatePicker.Icon")));
            this.dpDatePicker.IconColor = System.Drawing.Color.Gray;
            this.dpDatePicker.IconLocation = Bunifu.UI.WinForms.BunifuDatePicker.Indicator.Right;
            this.dpDatePicker.LeftTextMargin = 5;
            this.dpDatePicker.Location = new System.Drawing.Point(174, 128);
            this.dpDatePicker.MinimumSize = new System.Drawing.Size(0, 32);
            this.dpDatePicker.Name = "dpDatePicker";
            this.dpDatePicker.Size = new System.Drawing.Size(322, 34);
            this.dpDatePicker.TabIndex = 6;
            // 
            // dgwProducts
            // 
            this.dgwProducts.AllowCustomTheming = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.dgwProducts.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgwProducts.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgwProducts.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(92)))), ((int)(((byte)(188)))));
            this.dgwProducts.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgwProducts.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgwProducts.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgwProducts.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgwProducts.ColumnHeadersHeight = 40;
            this.dgwProducts.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.dgwProducts.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dgwProducts.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgwProducts.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dgwProducts.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgwProducts.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.dgwProducts.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dgwProducts.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.dgwProducts.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dgwProducts.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgwProducts.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.dgwProducts.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.dgwProducts.CurrentTheme.Name = null;
            this.dgwProducts.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgwProducts.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dgwProducts.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgwProducts.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dgwProducts.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgwProducts.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgwProducts.EnableHeadersVisualStyles = false;
            this.dgwProducts.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dgwProducts.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.dgwProducts.HeaderBgColor = System.Drawing.Color.Empty;
            this.dgwProducts.HeaderForeColor = System.Drawing.Color.White;
            this.dgwProducts.Location = new System.Drawing.Point(532, 359);
            this.dgwProducts.Name = "dgwProducts";
            this.dgwProducts.RowHeadersVisible = false;
            this.dgwProducts.RowHeadersWidth = 51;
            this.dgwProducts.RowTemplate.Height = 40;
            this.dgwProducts.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgwProducts.Size = new System.Drawing.Size(665, 388);
            this.dgwProducts.TabIndex = 5;
            this.dgwProducts.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            // 
            // dgvMeal
            // 
            this.dgvMeal.AllowCustomTheming = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.dgvMeal.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvMeal.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvMeal.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(92)))), ((int)(((byte)(188)))));
            this.dgvMeal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvMeal.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvMeal.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvMeal.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvMeal.ColumnHeadersHeight = 40;
            this.dgvMeal.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.dgvMeal.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dgvMeal.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvMeal.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dgvMeal.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvMeal.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.dgvMeal.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dgvMeal.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.dgvMeal.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dgvMeal.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgvMeal.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.dgvMeal.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.dgvMeal.CurrentTheme.Name = null;
            this.dgvMeal.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvMeal.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dgvMeal.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvMeal.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dgvMeal.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvMeal.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgvMeal.EnableHeadersVisualStyles = false;
            this.dgvMeal.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dgvMeal.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.dgvMeal.HeaderBgColor = System.Drawing.Color.Empty;
            this.dgvMeal.HeaderForeColor = System.Drawing.Color.White;
            this.dgvMeal.Location = new System.Drawing.Point(532, 18);
            this.dgvMeal.Name = "dgvMeal";
            this.dgvMeal.RowHeadersVisible = false;
            this.dgvMeal.RowHeadersWidth = 51;
            this.dgvMeal.RowTemplate.Height = 40;
            this.dgvMeal.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvMeal.Size = new System.Drawing.Size(665, 331);
            this.dgvMeal.TabIndex = 5;
            this.dgvMeal.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            this.dgvMeal.SelectionChanged += new System.EventHandler(this.dgvMeal_SelectionChanged);
            // 
            // ddMeal
            // 
            this.ddMeal.BackColor = System.Drawing.Color.Transparent;
            this.ddMeal.BackgroundColor = System.Drawing.Color.White;
            this.ddMeal.BorderColor = System.Drawing.Color.Silver;
            this.ddMeal.BorderRadius = 1;
            this.ddMeal.Color = System.Drawing.Color.Silver;
            this.ddMeal.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.ddMeal.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ddMeal.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ddMeal.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ddMeal.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.ddMeal.DisabledIndicatorColor = System.Drawing.Color.DarkGray;
            this.ddMeal.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ddMeal.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin;
            this.ddMeal.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddMeal.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.ddMeal.FillDropDown = true;
            this.ddMeal.FillIndicator = false;
            this.ddMeal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ddMeal.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ddMeal.ForeColor = System.Drawing.Color.Black;
            this.ddMeal.FormattingEnabled = true;
            this.ddMeal.Icon = null;
            this.ddMeal.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.ddMeal.IndicatorColor = System.Drawing.Color.DarkGray;
            this.ddMeal.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.ddMeal.IndicatorThickness = 2;
            this.ddMeal.IsDropdownOpened = false;
            this.ddMeal.ItemBackColor = System.Drawing.Color.White;
            this.ddMeal.ItemBorderColor = System.Drawing.Color.White;
            this.ddMeal.ItemForeColor = System.Drawing.Color.Black;
            this.ddMeal.ItemHeight = 26;
            this.ddMeal.ItemHighLightColor = System.Drawing.Color.DodgerBlue;
            this.ddMeal.ItemHighLightForeColor = System.Drawing.Color.White;
            this.ddMeal.Items.AddRange(new object[] {
            "Breakfast",
            "Lunch",
            "Dinner",
            "Snack"});
            this.ddMeal.ItemTopMargin = 3;
            this.ddMeal.Location = new System.Drawing.Point(174, 90);
            this.ddMeal.Name = "ddMeal";
            this.ddMeal.Size = new System.Drawing.Size(319, 32);
            this.ddMeal.TabIndex = 4;
            this.ddMeal.Text = null;
            this.ddMeal.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.ddMeal.TextLeftMargin = 5;
            // 
            // ddProduct
            // 
            this.ddProduct.BackColor = System.Drawing.Color.Transparent;
            this.ddProduct.BackgroundColor = System.Drawing.Color.White;
            this.ddProduct.BorderColor = System.Drawing.Color.Silver;
            this.ddProduct.BorderRadius = 1;
            this.ddProduct.Color = System.Drawing.Color.Silver;
            this.ddProduct.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.ddProduct.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ddProduct.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ddProduct.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ddProduct.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.ddProduct.DisabledIndicatorColor = System.Drawing.Color.DarkGray;
            this.ddProduct.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ddProduct.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin;
            this.ddProduct.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddProduct.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.ddProduct.FillDropDown = true;
            this.ddProduct.FillIndicator = false;
            this.ddProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ddProduct.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ddProduct.ForeColor = System.Drawing.Color.Black;
            this.ddProduct.FormattingEnabled = true;
            this.ddProduct.Icon = null;
            this.ddProduct.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.ddProduct.IndicatorColor = System.Drawing.Color.DarkGray;
            this.ddProduct.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.ddProduct.IndicatorThickness = 2;
            this.ddProduct.IsDropdownOpened = false;
            this.ddProduct.ItemBackColor = System.Drawing.Color.White;
            this.ddProduct.ItemBorderColor = System.Drawing.Color.White;
            this.ddProduct.ItemForeColor = System.Drawing.Color.Black;
            this.ddProduct.ItemHeight = 26;
            this.ddProduct.ItemHighLightColor = System.Drawing.Color.DodgerBlue;
            this.ddProduct.ItemHighLightForeColor = System.Drawing.Color.White;
            this.ddProduct.ItemTopMargin = 3;
            this.ddProduct.Location = new System.Drawing.Point(145, 450);
            this.ddProduct.Name = "ddProduct";
            this.ddProduct.Size = new System.Drawing.Size(319, 32);
            this.ddProduct.TabIndex = 4;
            this.ddProduct.Text = null;
            this.ddProduct.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.ddProduct.TextLeftMargin = 5;
            this.ddProduct.SelectedIndexChanged += new System.EventHandler(this.ddProduct_SelectedIndexChanged);
            // 
            // ddCategoryMeal
            // 
            this.ddCategoryMeal.BackColor = System.Drawing.Color.Transparent;
            this.ddCategoryMeal.BackgroundColor = System.Drawing.Color.White;
            this.ddCategoryMeal.BorderColor = System.Drawing.Color.Silver;
            this.ddCategoryMeal.BorderRadius = 1;
            this.ddCategoryMeal.Color = System.Drawing.Color.Silver;
            this.ddCategoryMeal.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.ddCategoryMeal.DisabledBackColor = System.Drawing.Color.DodgerBlue;
            this.ddCategoryMeal.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ddCategoryMeal.DisabledColor = System.Drawing.Color.DodgerBlue;
            this.ddCategoryMeal.DisabledForeColor = System.Drawing.Color.DodgerBlue;
            this.ddCategoryMeal.DisabledIndicatorColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.ddCategoryMeal.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ddCategoryMeal.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin;
            this.ddCategoryMeal.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddCategoryMeal.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.ddCategoryMeal.FillDropDown = true;
            this.ddCategoryMeal.FillIndicator = false;
            this.ddCategoryMeal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ddCategoryMeal.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ddCategoryMeal.ForeColor = System.Drawing.Color.Black;
            this.ddCategoryMeal.FormattingEnabled = true;
            this.ddCategoryMeal.Icon = null;
            this.ddCategoryMeal.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.ddCategoryMeal.IndicatorColor = System.Drawing.Color.DarkGray;
            this.ddCategoryMeal.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.ddCategoryMeal.IndicatorThickness = 2;
            this.ddCategoryMeal.IsDropdownOpened = false;
            this.ddCategoryMeal.ItemBackColor = System.Drawing.Color.DodgerBlue;
            this.ddCategoryMeal.ItemBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.ddCategoryMeal.ItemForeColor = System.Drawing.Color.Black;
            this.ddCategoryMeal.ItemHeight = 26;
            this.ddCategoryMeal.ItemHighLightColor = System.Drawing.Color.DarkTurquoise;
            this.ddCategoryMeal.ItemHighLightForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.ddCategoryMeal.ItemTopMargin = 3;
            this.ddCategoryMeal.Location = new System.Drawing.Point(145, 409);
            this.ddCategoryMeal.Name = "ddCategoryMeal";
            this.ddCategoryMeal.Size = new System.Drawing.Size(319, 32);
            this.ddCategoryMeal.TabIndex = 4;
            this.ddCategoryMeal.Text = null;
            this.ddCategoryMeal.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.ddCategoryMeal.TextLeftMargin = 5;
            this.ddCategoryMeal.SelectedIndexChanged += new System.EventHandler(this.ddCategoryMeal_SelectedIndexChanged);
            // 
            // bunifuLabel8
            // 
            this.bunifuLabel8.AllowParentOverrides = false;
            this.bunifuLabel8.AutoEllipsis = false;
            this.bunifuLabel8.AutoSize = false;
            this.bunifuLabel8.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel8.Font = new System.Drawing.Font("Monotype Corsiva", 35F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel8.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel8.Location = new System.Drawing.Point(19, 347);
            this.bunifuLabel8.Name = "bunifuLabel8";
            this.bunifuLabel8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel8.Size = new System.Drawing.Size(244, 56);
            this.bunifuLabel8.TabIndex = 3;
            this.bunifuLabel8.Text = "Add Product";
            this.bunifuLabel8.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel8.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // btnDeleteProduct
            // 
            this.btnDeleteProduct.ActiveBorderThickness = 1;
            this.btnDeleteProduct.ActiveCornerRadius = 20;
            this.btnDeleteProduct.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnDeleteProduct.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnDeleteProduct.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnDeleteProduct.BackColor = System.Drawing.Color.Transparent;
            this.btnDeleteProduct.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDeleteProduct.BackgroundImage")));
            this.btnDeleteProduct.ButtonText = "Delete";
            this.btnDeleteProduct.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnDeleteProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnDeleteProduct.IdleBorderThickness = 2;
            this.btnDeleteProduct.IdleCornerRadius = 20;
            this.btnDeleteProduct.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnDeleteProduct.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnDeleteProduct.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnDeleteProduct.Location = new System.Drawing.Point(340, 561);
            this.btnDeleteProduct.Margin = new System.Windows.Forms.Padding(5);
            this.btnDeleteProduct.Name = "btnDeleteProduct";
            this.btnDeleteProduct.Size = new System.Drawing.Size(165, 57);
            this.btnDeleteProduct.TabIndex = 2;
            this.btnDeleteProduct.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDeleteProduct.Click += new System.EventHandler(this.btnDeleteProduct_Click);
            // 
            // btnBackAddMeal
            // 
            this.btnBackAddMeal.ActiveBorderThickness = 1;
            this.btnBackAddMeal.ActiveCornerRadius = 20;
            this.btnBackAddMeal.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnBackAddMeal.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnBackAddMeal.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnBackAddMeal.BackColor = System.Drawing.Color.Transparent;
            this.btnBackAddMeal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBackAddMeal.BackgroundImage")));
            this.btnBackAddMeal.ButtonText = "Back";
            this.btnBackAddMeal.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnBackAddMeal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnBackAddMeal.IdleBorderThickness = 2;
            this.btnBackAddMeal.IdleCornerRadius = 20;
            this.btnBackAddMeal.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnBackAddMeal.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnBackAddMeal.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnBackAddMeal.Location = new System.Drawing.Point(1032, 746);
            this.btnBackAddMeal.Margin = new System.Windows.Forms.Padding(5);
            this.btnBackAddMeal.Name = "btnBackAddMeal";
            this.btnBackAddMeal.Size = new System.Drawing.Size(165, 57);
            this.btnBackAddMeal.TabIndex = 2;
            this.btnBackAddMeal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnBackAddMeal.Click += new System.EventHandler(this.btnBackAddMeal_Click);
            // 
            // btnUpdateProduct
            // 
            this.btnUpdateProduct.ActiveBorderThickness = 1;
            this.btnUpdateProduct.ActiveCornerRadius = 20;
            this.btnUpdateProduct.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdateProduct.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnUpdateProduct.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdateProduct.BackColor = System.Drawing.Color.Transparent;
            this.btnUpdateProduct.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUpdateProduct.BackgroundImage")));
            this.btnUpdateProduct.ButtonText = "Update";
            this.btnUpdateProduct.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnUpdateProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnUpdateProduct.IdleBorderThickness = 2;
            this.btnUpdateProduct.IdleCornerRadius = 20;
            this.btnUpdateProduct.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnUpdateProduct.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnUpdateProduct.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnUpdateProduct.Location = new System.Drawing.Point(174, 561);
            this.btnUpdateProduct.Margin = new System.Windows.Forms.Padding(5);
            this.btnUpdateProduct.Name = "btnUpdateProduct";
            this.btnUpdateProduct.Size = new System.Drawing.Size(165, 57);
            this.btnUpdateProduct.TabIndex = 2;
            this.btnUpdateProduct.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnUpdateProduct.Click += new System.EventHandler(this.btnUpdateProduct_Click);
            // 
            // bunifuLabel3
            // 
            this.bunifuLabel3.AllowParentOverrides = false;
            this.bunifuLabel3.AutoEllipsis = false;
            this.bunifuLabel3.AutoSize = false;
            this.bunifuLabel3.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel3.Font = new System.Drawing.Font("Monotype Corsiva", 35F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel3.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel3.Location = new System.Drawing.Point(16, 11);
            this.bunifuLabel3.Name = "bunifuLabel3";
            this.bunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel3.Size = new System.Drawing.Size(191, 56);
            this.bunifuLabel3.TabIndex = 3;
            this.bunifuLabel3.Text = "Add Meal";
            this.bunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.ActiveBorderThickness = 1;
            this.btnAddProduct.ActiveCornerRadius = 20;
            this.btnAddProduct.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnAddProduct.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnAddProduct.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnAddProduct.BackColor = System.Drawing.Color.Transparent;
            this.btnAddProduct.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAddProduct.BackgroundImage")));
            this.btnAddProduct.ButtonText = "Add";
            this.btnAddProduct.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnAddProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnAddProduct.IdleBorderThickness = 2;
            this.btnAddProduct.IdleCornerRadius = 20;
            this.btnAddProduct.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnAddProduct.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnAddProduct.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnAddProduct.Location = new System.Drawing.Point(8, 561);
            this.btnAddProduct.Margin = new System.Windows.Forms.Padding(5);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(165, 57);
            this.btnAddProduct.TabIndex = 2;
            this.btnAddProduct.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // btnUpdateMeal
            // 
            this.btnUpdateMeal.ActiveBorderThickness = 1;
            this.btnUpdateMeal.ActiveCornerRadius = 20;
            this.btnUpdateMeal.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdateMeal.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnUpdateMeal.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdateMeal.BackColor = System.Drawing.Color.Transparent;
            this.btnUpdateMeal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUpdateMeal.BackgroundImage")));
            this.btnUpdateMeal.ButtonText = "Update";
            this.btnUpdateMeal.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnUpdateMeal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnUpdateMeal.IdleBorderThickness = 2;
            this.btnUpdateMeal.IdleCornerRadius = 20;
            this.btnUpdateMeal.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnUpdateMeal.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnUpdateMeal.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnUpdateMeal.Location = new System.Drawing.Point(174, 168);
            this.btnUpdateMeal.Margin = new System.Windows.Forms.Padding(5);
            this.btnUpdateMeal.Name = "btnUpdateMeal";
            this.btnUpdateMeal.Size = new System.Drawing.Size(165, 57);
            this.btnUpdateMeal.TabIndex = 2;
            this.btnUpdateMeal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnUpdateMeal.Click += new System.EventHandler(this.btnUpdateMeal_Click);
            // 
            // btnDeleteMeal
            // 
            this.btnDeleteMeal.ActiveBorderThickness = 1;
            this.btnDeleteMeal.ActiveCornerRadius = 20;
            this.btnDeleteMeal.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnDeleteMeal.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnDeleteMeal.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnDeleteMeal.BackColor = System.Drawing.Color.Transparent;
            this.btnDeleteMeal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDeleteMeal.BackgroundImage")));
            this.btnDeleteMeal.ButtonText = "Delete";
            this.btnDeleteMeal.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnDeleteMeal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnDeleteMeal.IdleBorderThickness = 2;
            this.btnDeleteMeal.IdleCornerRadius = 20;
            this.btnDeleteMeal.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnDeleteMeal.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnDeleteMeal.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnDeleteMeal.Location = new System.Drawing.Point(340, 168);
            this.btnDeleteMeal.Margin = new System.Windows.Forms.Padding(5);
            this.btnDeleteMeal.Name = "btnDeleteMeal";
            this.btnDeleteMeal.Size = new System.Drawing.Size(165, 57);
            this.btnDeleteMeal.TabIndex = 2;
            this.btnDeleteMeal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDeleteMeal.Click += new System.EventHandler(this.btnDeleteMeal_Click);
            // 
            // btnAddMeal
            // 
            this.btnAddMeal.ActiveBorderThickness = 1;
            this.btnAddMeal.ActiveCornerRadius = 20;
            this.btnAddMeal.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnAddMeal.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnAddMeal.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnAddMeal.BackColor = System.Drawing.Color.Transparent;
            this.btnAddMeal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAddMeal.BackgroundImage")));
            this.btnAddMeal.ButtonText = "Add";
            this.btnAddMeal.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnAddMeal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.btnAddMeal.IdleBorderThickness = 2;
            this.btnAddMeal.IdleCornerRadius = 20;
            this.btnAddMeal.IdleFillColor = System.Drawing.Color.DarkTurquoise;
            this.btnAddMeal.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnAddMeal.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnAddMeal.Location = new System.Drawing.Point(8, 168);
            this.btnAddMeal.Margin = new System.Windows.Forms.Padding(5);
            this.btnAddMeal.Name = "btnAddMeal";
            this.btnAddMeal.Size = new System.Drawing.Size(165, 57);
            this.btnAddMeal.TabIndex = 2;
            this.btnAddMeal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAddMeal.Click += new System.EventHandler(this.btnAddMeal_Click);
            // 
            // bunifuLabel4
            // 
            this.bunifuLabel4.AllowParentOverrides = false;
            this.bunifuLabel4.AutoEllipsis = false;
            this.bunifuLabel4.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel4.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel4.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel4.Location = new System.Drawing.Point(19, 501);
            this.bunifuLabel4.Name = "bunifuLabel4";
            this.bunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel4.Size = new System.Drawing.Size(120, 31);
            this.bunifuLabel4.TabIndex = 1;
            this.bunifuLabel4.Text = "Portion(gr)";
            this.bunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel4.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel13
            // 
            this.bunifuLabel13.AllowParentOverrides = false;
            this.bunifuLabel13.AutoEllipsis = false;
            this.bunifuLabel13.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel13.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel13.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel13.Location = new System.Drawing.Point(19, 128);
            this.bunifuLabel13.Name = "bunifuLabel13";
            this.bunifuLabel13.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel13.Size = new System.Drawing.Size(126, 31);
            this.bunifuLabel13.TabIndex = 1;
            this.bunifuLabel13.Text = "Meal\'s Date";
            this.bunifuLabel13.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel13.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel12
            // 
            this.bunifuLabel12.AllowParentOverrides = false;
            this.bunifuLabel12.AutoEllipsis = false;
            this.bunifuLabel12.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel12.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel12.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel12.Location = new System.Drawing.Point(19, 84);
            this.bunifuLabel12.Name = "bunifuLabel12";
            this.bunifuLabel12.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel12.Size = new System.Drawing.Size(53, 31);
            this.bunifuLabel12.TabIndex = 1;
            this.bunifuLabel12.Text = "Meal";
            this.bunifuLabel12.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel12.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel5
            // 
            this.bunifuLabel5.AllowParentOverrides = false;
            this.bunifuLabel5.AutoEllipsis = false;
            this.bunifuLabel5.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel5.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel5.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel5.Location = new System.Drawing.Point(19, 450);
            this.bunifuLabel5.Name = "bunifuLabel5";
            this.bunifuLabel5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel5.Size = new System.Drawing.Size(85, 31);
            this.bunifuLabel5.TabIndex = 1;
            this.bunifuLabel5.Text = "Product";
            this.bunifuLabel5.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel5.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AllowParentOverrides = false;
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bunifuLabel1.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.bunifuLabel1.Location = new System.Drawing.Point(19, 409);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(96, 31);
            this.bunifuLabel1.TabIndex = 1;
            this.bunifuLabel1.Text = "Category";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // txtPortion
            // 
            this.txtPortion.AcceptsReturn = false;
            this.txtPortion.AcceptsTab = false;
            this.txtPortion.AnimationSpeed = 200;
            this.txtPortion.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtPortion.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtPortion.AutoSizeHeight = true;
            this.txtPortion.BackColor = System.Drawing.Color.Transparent;
            this.txtPortion.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtPortion.BackgroundImage")));
            this.txtPortion.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtPortion.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtPortion.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtPortion.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtPortion.BorderRadius = 1;
            this.txtPortion.BorderThickness = 2;
            this.txtPortion.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.txtPortion.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtPortion.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtPortion.DefaultText = "";
            this.txtPortion.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            this.txtPortion.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.txtPortion.HideSelection = true;
            this.txtPortion.IconLeft = null;
            this.txtPortion.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPortion.IconPadding = 10;
            this.txtPortion.IconRight = null;
            this.txtPortion.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPortion.Lines = new string[0];
            this.txtPortion.Location = new System.Drawing.Point(145, 488);
            this.txtPortion.MaxLength = 32767;
            this.txtPortion.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtPortion.Modified = false;
            this.txtPortion.Multiline = false;
            this.txtPortion.Name = "txtPortion";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtPortion.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtPortion.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtPortion.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(60)))), ((int)(((byte)(212)))));
            stateProperties4.ForeColor = System.Drawing.Color.DarkTurquoise;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtPortion.OnIdleState = stateProperties4;
            this.txtPortion.Padding = new System.Windows.Forms.Padding(3);
            this.txtPortion.PasswordChar = '\0';
            this.txtPortion.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtPortion.PlaceholderText = "Enter text";
            this.txtPortion.ReadOnly = false;
            this.txtPortion.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPortion.SelectedText = "";
            this.txtPortion.SelectionLength = 0;
            this.txtPortion.SelectionStart = 0;
            this.txtPortion.ShortcutsEnabled = true;
            this.txtPortion.Size = new System.Drawing.Size(319, 50);
            this.txtPortion.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtPortion.TabIndex = 0;
            this.txtPortion.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtPortion.TextMarginBottom = 0;
            this.txtPortion.TextMarginLeft = 3;
            this.txtPortion.TextMarginTop = 1;
            this.txtPortion.TextPlaceholder = "Enter text";
            this.txtPortion.UseSystemPasswordChar = false;
            this.txtPortion.WordWrap = true;
            // 
            // AddMeal
            // 
            this.ClientSize = new System.Drawing.Size(1200, 800);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddMeal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.AddMeal_Load);
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbProduct)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgwProducts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMeal)).EndInit();
            this.ResumeLayout(false);

        }


        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.UI.WinForms.BunifuDropdown ddProduct;
        private Bunifu.UI.WinForms.BunifuDropdown ddCategoryMeal;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel3;
        private Bunifu.Framework.UI.BunifuThinButton2 btnAddMeal;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel5;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.Framework.UI.BunifuThinButton2 btnDeleteMeal;
        private Bunifu.UI.WinForms.BunifuDataGridView dgvMeal;
        private Bunifu.UI.WinForms.BunifuDataGridView dgwProducts;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel8;
        private Bunifu.Framework.UI.BunifuThinButton2 btnAddProduct;
        private Bunifu.Framework.UI.BunifuThinButton2 btnDeleteProduct;
        private Bunifu.Framework.UI.BunifuThinButton2 btnUpdateProduct;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel4;
        private Bunifu.UI.WinForms.BunifuTextBox txtPortion;
        private Bunifu.UI.WinForms.BunifuDatePicker dpDatePicker;
        private Bunifu.UI.WinForms.BunifuDropdown ddMeal;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel13;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel12;
        private Bunifu.Framework.UI.BunifuThinButton2 btnBackAddMeal;
        private Bunifu.Framework.UI.BunifuThinButton2 btnUpdateMeal;
        private Bunifu.UI.WinForms.BunifuPictureBox pbProduct;
    }
}