﻿using HealthLife_BLL.Controllers;
using HealthLife_Model.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HealthLife_UI
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        private void btnRegisterRegister_Click(object sender, EventArgs e)
        {
            if (UserController.IsValidEmail(txtEMailRegister.Text))
            {

                if (UserController.CheckPassword(txtPasswordRegister.Text))
                {

                    if (txtEMailRegister.Text != null && txtPasswordRegister.Text != null && txtRePasswordRegister.Text != null && txtRePasswordRegister.Text == txtPasswordRegister.Text)
                    {
                        User u1 = new User();
                        u1.Mail= txtEMailRegister.Text;
                        u1.Password= txtPasswordRegister.Text;
                        UserController.AddUser(u1);
                        MessageBox.Show("User Created.");
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Please fill all informations!");
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Please enter password in requested features");
                    return;
                } 
            }
            else
            {
                MessageBox.Show("Please enter e-mail in requested features");
            }
        }

        private void btnBackRegister_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
