﻿using HealthLife_BLL.Controllers;
using HealthLife_Model.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using Image = System.Drawing.Image;

namespace HealthLife_UI
{
    public partial class UserInformation : Form
    {
        User loginedUser = UserController.GetUserByUserID(UserController.LoginedUserID);
        public UserInformation()
        {
            InitializeComponent();
        }
        private void UserInformation_Load(object sender, EventArgs e)
        {
            lblName.Text = loginedUser.Name;
            lblHeight.Text = loginedUser.Height.ToString();
            lblCity.Text = loginedUser.City;
            lblWeight.Text = loginedUser.Weight.ToString();
            if (loginedUser.Weight != null && loginedUser.Height != null)
            {
                lblBMI.Text = Math.Round((double)(loginedUser.Weight*10000 / Math.Pow(Convert.ToDouble(loginedUser.Height), 2d)),2).ToString();

            }
            else
            {
                lblBMI.Text = "Not Calculated";
            }
            
            if (loginedUser.Photo != null)
            {               
                Image image;
                using (MemoryStream stream = new MemoryStream(loginedUser.Photo))
                {
                    image = Image.FromStream(stream);
                }
                pbUpdateUserInformation.Image = image;
                pbUserInformation.Image = image;
            }
        }
        private void btnUpdateProduct_Click(object sender, EventArgs e)
        {
            if (txtNameUpdateUser.Text != null)
            {
                loginedUser.Name = txtNameUpdateUser.Text;
                lblName.Text = loginedUser.Name;
            }
            if (txtHeightUpdateUser.Text != null)
            {
                loginedUser.Height = Convert.ToDouble(txtHeightUpdateUser.Text);
                lblHeight.Text = loginedUser.Height.ToString();
            }
            if (txtCityUpdateUser.Text != null)
            {
                loginedUser.City = txtCityUpdateUser.Text;
                lblCity.Text = loginedUser.City;
            }
            if (txtWeightUpdateUser.Text != null)
            {
                loginedUser.Weight = Convert.ToDouble(txtWeightUpdateUser.Text);
                lblWeight.Text = loginedUser.Weight.ToString();
            }
            if (loginedUser.Weight != null && loginedUser.Height != null)
            {
                lblBMI.Text = Math.Round((double)(loginedUser.Weight * 10000 / Math.Pow(Convert.ToDouble(loginedUser.Height), 2d)), 2).ToString();
            }
            else
            {
                lblBMI.Text = "Not Calculated";
            }
            UserController.UpdateUser(loginedUser);
            MessageBox.Show("Your Profile Has Been Updated.");
        }
        private void btnBackUserInformation_Click(object sender, EventArgs e)
        {
            Main main = new Main();
            this.Close();
            main.ShowDialog();
        }

        private void btnAddPhoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.ShowDialog();
            txtPhotoUpdateUser.ReadOnly = true;
            txtPhotoUpdateUser.Text = openFileDialog.FileName;
            loginedUser.Photo = File.ReadAllBytes(txtPhotoUpdateUser.Text);
            Image image;
            using (MemoryStream stream = new MemoryStream(loginedUser.Photo))
            {
                image = Image.FromStream(stream);
            }
            pbUpdateUserInformation.Image = image;
            pbUserInformation.Image = image;
            UserController.UpdateUser(loginedUser);
            MessageBox.Show("Your Profile Photos Has Been Updated.");
        }

        private void btnDeleteUser_Click(object sender, EventArgs e)
        {
            UserController.DeleteUser(loginedUser);
            MessageBox.Show("Your Account has been deleted");
            this.Close();
            Login login = new Login();
            login.ShowDialog();

        }
    }
}
